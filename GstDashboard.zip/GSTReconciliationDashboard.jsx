import { useState, useEffect, useRef } from "react";

// ─────────────────────────────────────────────────────────────────────────────
// EMBEDDED DATA (from backend generation)
// ─────────────────────────────────────────────────────────────────────────────

const SUMMARY = {
  total_taxpayers: 20, total_gstins: 29, total_invoices: 200,
  total_irns: 168, total_ewbs: 145, total_returns: 87, total_payments: 9,
  total_mismatches: 29, critical_mismatches: 9, high_mismatches: 13,
  total_itc_pool: 90557307.97, total_itc_at_risk: 8626672.37,
  itc_leakage_pct: 9.53, reconciliation_rate: 85.5,
  graph_stats: { total_nodes: 658, total_edges: 742, density: 0.001714,
    node_types: { Taxpayer: 20, GSTIN: 29, Invoice: 200, IRN: 168, EWayBill: 145, Return: 87, TaxPayment: 9 },
    relationship_types: { HAS_GSTIN: 29, ISSUED_BY: 200, ISSUED_TO: 200, HAS_IRN: 168, HAS_EWBILL: 145 }
  }
};

const MISMATCHES = [
  { mismatch_id: "MM_0001", invoice_id: "INV/012024/1003_27JHA", mismatch_type: "Missing in GSTR-2B", risk_level: "CRITICAL", supplier_gstin: "27JHACF2345P1Z6", buyer_gstin: "29ABCDE1234F1Z5", tax_period: "012024", expected_amount: 924500, actual_amount: 0, variance: 924500, variance_pct: 100, itc_at_risk: 924500, root_cause: "Supplier did not file GSTR-1 for this period; invoice not reflected in GSTR-2B", recommendation: "Contact supplier to file GSTR-1; hold ITC claim until reconciliation", audit_trail: ["[STEP 1] Invoice identified in Purchase Register (PR) for buyer GSTIN", "[STEP 2] Cross-referenced with GSTR-2B for period 012024", "[STEP 3] Invoice NOT found in GSTR-2B — supplier GSTR-1 check initiated", "[STEP 4] Supplier GSTIN GSTR-1 status: PENDING/NOT FILED", "[STEP 5] ITC of ₹9,24,500 flagged as INELIGIBLE until supplier compliance"] },
  { mismatch_id: "MM_0002", invoice_id: "INV/012024/1008_33XYZ", mismatch_type: "Duplicate Invoice", risk_level: "CRITICAL", supplier_gstin: "33XYZAB5678C2Z9", buyer_gstin: "07DEFGH9012I3Z4", tax_period: "012024", expected_amount: 348600, actual_amount: 348600, variance: 348600, variance_pct: 100, itc_at_risk: 348600, root_cause: "Same invoice number reported twice with different dates — duplicate ITC claim detected", recommendation: "Immediate reversal of duplicate ITC; possible penalty u/s 74", audit_trail: ["[STEP 1] Invoice identified in Purchase Register", "[STEP 2] Cross-referenced with GSTR-2B", "[STEP 3] Identical invoice_no detected in GSTR-2B for two separate periods", "[STEP 4] Hash comparison of invoice data reveals same supplier+amount+date", "[STEP 5] DUPLICATE ITC claim of ₹3,48,600 flagged for reversal"] },
  { mismatch_id: "MM_0003", invoice_id: "INV/012024/1012_07MNO", mismatch_type: "IRN Not Found", risk_level: "HIGH", supplier_gstin: "07MNOPQ3456R4Z1", buyer_gstin: "24RSTUV7890S5Z2", tax_period: "012024", expected_amount: 2150000, actual_amount: 0, variance: 2150000, variance_pct: 100, itc_at_risk: 2150000, root_cause: "Invoice value exceeds ₹5 Cr threshold but no IRN generated — possible fake invoice", recommendation: "Verify physical delivery; request IRN from supplier; potential fraud alert", audit_trail: ["[STEP 1] Invoice identified in Purchase Register", "[STEP 2] Cross-referenced with GSTR-2B", "[STEP 3] Invoice value ₹21,50,000 > ₹5Cr threshold — IRN mandatory", "[STEP 4] IRP (Invoice Registration Portal) queried — IRN not found", "[STEP 5] Risk Classification: HIGH — Possible fake/fraudulent invoice"] },
  { mismatch_id: "MM_0004", invoice_id: "INV/012024/1019_36PQR", mismatch_type: "Amount Mismatch", risk_level: "HIGH", supplier_gstin: "36PQRST8901U6Z7", buyer_gstin: "27JHACF2345P1Z6", tax_period: "012024", expected_amount: 182400, actual_amount: 145920, variance: 36480, variance_pct: 20, itc_at_risk: 36480, root_cause: "Supplier filed incorrect tax amount in GSTR-1 vs e-Invoice amount", recommendation: "Issue SCN to supplier; reverse excess ITC claimed", audit_trail: ["[STEP 1] Invoice identified in Purchase Register", "[STEP 2] Amount in GSTR-2B differs from Purchase Register by > ₹500", "[STEP 3] e-Invoice (IRN) amount cross-checked: matches PR amount", "[STEP 4] GSTR-1 filed amount lower than e-Invoice — supplier amendment required"] },
  { mismatch_id: "MM_0005", invoice_id: "INV/012024/1025_09STU", mismatch_type: "E-Way Bill Mismatch", risk_level: "MEDIUM", supplier_gstin: "09STUVW2345X7Z3", buyer_gstin: "33XYZAB5678C2Z9", tax_period: "012024", expected_amount: 450000, actual_amount: 360000, variance: 90000, variance_pct: 20, itc_at_risk: 16200, root_cause: "E-Way Bill value significantly lower than invoice value — under-declaration suspicion", recommendation: "Cross-check with transporter records; verify vehicle movement logs", audit_trail: ["[STEP 1] Invoice identified in Purchase Register", "[STEP 2] E-Way Bill retrieved for invoice — value mismatch detected", "[STEP 3] EWB value < Invoice value by > 20%", "[STEP 4] Physical movement verification recommended"] },
  { mismatch_id: "MM_0006", invoice_id: "INV/012024/1031_19VWX", mismatch_type: "Missing in GSTR-2B", risk_level: "CRITICAL", supplier_gstin: "19VWXYZ6789A8Z5", buyer_gstin: "36PQRST8901U6Z7", tax_period: "012024", expected_amount: 675000, actual_amount: 0, variance: 675000, variance_pct: 100, itc_at_risk: 675000, root_cause: "Supplier cancelled GSTIN after issuing invoice; GSTR-1 cannot be filed", recommendation: "ITC denied; pursue civil remedy against supplier", audit_trail: ["[STEP 1] Invoice found in PR", "[STEP 2] GSTR-2B check shows invoice absent", "[STEP 3] Supplier GSTIN found CANCELLED in GST portal", "[STEP 4] ITC claim invalid — GSTIN suspended"] },
  { mismatch_id: "MM_0007", invoice_id: "INV/012024/1040_32YZA", mismatch_type: "Amount Mismatch", risk_level: "MEDIUM", supplier_gstin: "32YZABC1234D9Z2", buyer_gstin: "09STUVW2345X7Z3", tax_period: "012024", expected_amount: 89100, actual_amount: 71280, variance: 17820, variance_pct: 20, itc_at_risk: 17820, root_cause: "CGST/SGST incorrectly split; supplier applied IGST instead of intra-state rates", recommendation: "Supplier to file amendment; buyer to reconcile ledger entries", audit_trail: ["[STEP 1] Invoice found in PR", "[STEP 2] Tax type mismatch: PR shows CGST+SGST, GSTR-2B shows IGST", "[STEP 3] Place of supply analysis confirms intra-state supply", "[STEP 4] Supplier must amend GSTR-1 with correct tax heads"] },
  { mismatch_id: "MM_0008", invoice_id: "INV/012024/1047_24BCD", mismatch_type: "Duplicate Invoice", risk_level: "CRITICAL", supplier_gstin: "24BCDEF5678G0Z8", buyer_gstin: "19VWXYZ6789A8Z5", tax_period: "012024", expected_amount: 512000, actual_amount: 512000, variance: 512000, variance_pct: 100, itc_at_risk: 512000, root_cause: "Duplicate invoice detected across two return periods with same data hash", recommendation: "Reverse duplicate entry; file GSTR-3B amendment", audit_trail: ["[STEP 1] Invoice found in PR", "[STEP 2] Duplicate detection: same invoice hash in Jan and Feb GSTR-2B", "[STEP 3] ITC double-claimed: ₹5,12,000 flagged", "[STEP 4] Penalty notice to be issued"] },
  { mismatch_id: "MM_0009", invoice_id: "INV/012024/1053_07CDE", mismatch_type: "IRN Not Found", risk_level: "HIGH", supplier_gstin: "07CDEFG9012H1Z4", buyer_gstin: "32YZABC1234D9Z2", tax_period: "012024", expected_amount: 385200, actual_amount: 0, variance: 385200, variance_pct: 100, itc_at_risk: 385200, root_cause: "e-Invoice mandatory for this supplier turnover bracket but IRN absent", recommendation: "Supplier to register on IRP and generate IRN; buyer to hold ITC", audit_trail: ["[STEP 1] Invoice in PR with value > threshold", "[STEP 2] IRP query returned no matching IRN", "[STEP 3] Compliance check: supplier turnover > ₹10Cr — e-Invoice mandatory", "[STEP 4] ITC of ₹3,85,200 blocked until IRN generated"] },
];

const VENDORS = [
  { gstin: "27JHACF2345P1Z6", legal_name: "Apex Chemical Industries Ltd", sector: "Chemical", compliance_score: 45.2, risk_score: 78.4, total_supplied_tax: 2840000, itc_at_risk: 1240000, mismatch_count: 4, invoice_count: 18, mismatch_rate: 22.2, status: "Non-Compliant", state: "Maharashtra" },
  { gstin: "33XYZAB5678C2Z9", legal_name: "Bharat Textile Trading Co", sector: "Textiles", compliance_score: 38.7, risk_score: 74.1, total_supplied_tax: 1920000, itc_at_risk: 960000, mismatch_count: 3, invoice_count: 15, mismatch_rate: 20.0, status: "Non-Compliant", state: "Tamil Nadu" },
  { gstin: "07MNOPQ3456R4Z1", legal_name: "Chandra IT Solutions Pvt Ltd", sector: "IT", compliance_score: 52.1, risk_score: 68.9, total_supplied_tax: 3450000, itc_at_risk: 2150000, mismatch_count: 2, invoice_count: 22, mismatch_rate: 9.1, status: "At Risk", state: "Delhi" },
  { gstin: "19VWXYZ6789A8Z5", legal_name: "Delta FMCG Enterprises Pvt Ltd", sector: "FMCG", compliance_score: 61.4, risk_score: 58.3, total_supplied_tax: 1680000, itc_at_risk: 675000, mismatch_count: 2, invoice_count: 14, mismatch_rate: 14.3, status: "At Risk", state: "West Bengal" },
  { gstin: "36PQRST8901U6Z7", legal_name: "Eagle Auto Components Ltd", sector: "Auto Components", compliance_score: 71.8, risk_score: 42.7, total_supplied_tax: 2120000, itc_at_risk: 385200, mismatch_count: 2, invoice_count: 19, mismatch_rate: 10.5, status: "At Risk", state: "Telangana" },
  { gstin: "09STUVW2345X7Z3", legal_name: "Falcon Manufacturing Ltd", sector: "Manufacturing", compliance_score: 79.3, risk_score: 31.2, total_supplied_tax: 1850000, itc_at_risk: 180000, mismatch_count: 1, invoice_count: 16, mismatch_rate: 6.3, status: "Compliant", state: "Uttar Pradesh" },
  { gstin: "24BCDEF5678G0Z8", legal_name: "Global Pharma Industries Ltd", sector: "Pharmaceuticals", compliance_score: 83.6, risk_score: 28.4, total_supplied_tax: 2780000, itc_at_risk: 512000, mismatch_count: 1, invoice_count: 21, mismatch_rate: 4.8, status: "Compliant", state: "Gujarat" },
  { gstin: "32YZABC1234D9Z2", legal_name: "Horizon Construction Pvt Ltd", sector: "Construction", compliance_score: 88.2, risk_score: 18.7, total_supplied_tax: 1340000, itc_at_risk: 90000, mismatch_count: 1, invoice_count: 12, mismatch_rate: 8.3, status: "Compliant", state: "Kerala" },
];

const ITC_CHAIN = {
  invoice_id: "INV/012024/1003_27JHA",
  is_valid: false,
  broken_at: "Supplier GSTR-1 not filed — ITC auto-blocked",
  invoice_data: { invoice_no: "INV/012024/1003", taxable_value: 5136111, total_tax: 924500, supplier_gstin: "27JHACF2345P1Z6", buyer_gstin: "29ABCDE1234F1Z5" },
  hops: [
    { hop: 1, name: "e-Invoice (IRN)", status: "✅ VALID", details: { ack_no: "112345678901234567", ack_date: "2024-01-15", cancelled: false } },
    { hop: 2, name: "E-Way Bill", status: "✅ FOUND", details: { ewb_no: "400000001", valid_upto: "2024-01-20", total_value: 6060611 } },
    { hop: 3, name: "GSTR-1 (Supplier)", status: "❌ PENDING", details: { filing_date: null, status: "Pending", total_igst: 0 } },
    { hop: 4, name: "GSTR-2B (Buyer)", status: "❌ NOT REFLECTED", details: { itc_available: 0 } },
    { hop: 5, name: "GSTR-3B (ITC Claim)", status: "⏳ PENDING", details: { itc_claimed: 0, tax_paid: 0 } },
  ]
};

// ─────────────────────────────────────────────────────────────────────────────
// UTILITY FUNCTIONS
// ─────────────────────────────────────────────────────────────────────────────

const fmt = (n) => new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(n);
const fmtCr = (n) => `₹${(n / 10000000).toFixed(2)} Cr`;
const fmtL = (n) => n >= 100000 ? `₹${(n / 100000).toFixed(1)}L` : `₹${fmt(n)}`;

const RISK_COLORS = {
  CRITICAL: { bg: "#FF2D55", text: "#FF2D55", badge: "rgba(255,45,85,0.15)", border: "rgba(255,45,85,0.4)" },
  HIGH: { bg: "#FF9500", text: "#FF9500", badge: "rgba(255,149,0,0.15)", border: "rgba(255,149,0,0.4)" },
  MEDIUM: { bg: "#FFCC00", text: "#FFCC00", badge: "rgba(255,204,0,0.15)", border: "rgba(255,204,0,0.4)" },
  LOW: { bg: "#34C759", text: "#34C759", badge: "rgba(52,199,89,0.15)", border: "rgba(52,199,89,0.4)" },
};

const MTYPE_ICONS = {
  "Missing in GSTR-2B": "⬛",
  "Duplicate Invoice": "🔁",
  "IRN Not Found": "🔍",
  "Amount Mismatch": "⚖️",
  "E-Way Bill Mismatch": "🚛",
};

// ─────────────────────────────────────────────────────────────────────────────
// COMPONENTS
// ─────────────────────────────────────────────────────────────────────────────

function KPICard({ label, value, sub, accent, icon }) {
  return (
    <div style={{
      background: "rgba(255,255,255,0.03)", border: `1px solid ${accent}30`,
      borderRadius: 16, padding: "20px 24px", position: "relative", overflow: "hidden",
      transition: "all 0.2s", cursor: "default",
    }}
    onMouseEnter={e => { e.currentTarget.style.background = "rgba(255,255,255,0.06)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
    onMouseLeave={e => { e.currentTarget.style.background = "rgba(255,255,255,0.03)"; e.currentTarget.style.transform = "none"; }}
    >
      <div style={{ position: "absolute", top: 16, right: 16, fontSize: 22, opacity: 0.4 }}>{icon}</div>
      <div style={{ fontSize: 11, color: "#888", letterSpacing: "0.12em", textTransform: "uppercase", marginBottom: 8, fontFamily: "mono" }}>{label}</div>
      <div style={{ fontSize: 28, fontWeight: 700, color: accent, fontFamily: "'Syne', sans-serif", lineHeight: 1 }}>{value}</div>
      {sub && <div style={{ fontSize: 12, color: "#666", marginTop: 6 }}>{sub}</div>}
      <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, height: 2, background: `linear-gradient(90deg, ${accent}80, transparent)` }} />
    </div>
  );
}

function RiskBadge({ level }) {
  const c = RISK_COLORS[level] || RISK_COLORS.LOW;
  return (
    <span style={{
      background: c.badge, color: c.text, border: `1px solid ${c.border}`,
      borderRadius: 6, padding: "2px 10px", fontSize: 11, fontWeight: 700,
      letterSpacing: "0.08em", fontFamily: "mono"
    }}>{level}</span>
  );
}

function MismatchDonut({ data }) {
  const total = data.reduce((s, d) => s + d.value, 0);
  let angle = -90;
  const cx = 80, cy = 80, r = 60, inner = 38;
  const paths = data.map(d => {
    const a1 = angle;
    const a2 = angle + (d.value / total) * 360;
    angle = a2;
    const toRad = a => a * Math.PI / 180;
    const x1 = cx + r * Math.cos(toRad(a1)), y1 = cy + r * Math.sin(toRad(a1));
    const x2 = cx + r * Math.cos(toRad(a2)), y2 = cy + r * Math.sin(toRad(a2));
    const xi1 = cx + inner * Math.cos(toRad(a1)), yi1 = cy + inner * Math.sin(toRad(a1));
    const xi2 = cx + inner * Math.cos(toRad(a2)), yi2 = cy + inner * Math.sin(toRad(a2));
    const large = (a2 - a1) > 180 ? 1 : 0;
    return <path key={d.label} d={`M${x1},${y1} A${r},${r} 0 ${large} 1 ${x2},${y2} L${xi2},${yi2} A${inner},${inner} 0 ${large} 0 ${xi1},${yi1} Z`} fill={d.color} opacity={0.85} />;
  });
  return (
    <svg width="160" height="160" viewBox="0 0 160 160">
      {paths}
      <circle cx={cx} cy={cy} r={inner - 2} fill="#0d0d1a" />
      <text x={cx} y={cy - 5} textAnchor="middle" fill="#fff" fontSize="16" fontWeight="700" fontFamily="Syne">{total}</text>
      <text x={cx} y={cy + 14} textAnchor="middle" fill="#666" fontSize="9" fontFamily="monospace">TOTAL</text>
    </svg>
  );
}

function GraphViz({ nodes_sample, edges_sample }) {
  const canvasRef = useRef(null);
  const animRef = useRef(null);
  const [hoveredNode, setHoveredNode] = useState(null);
  const nodesRef = useRef([]);
  const edgesRef = useRef([]);

  const TYPE_COLORS = {
    Taxpayer: "#7C3AED", GSTIN: "#2563EB", Invoice: "#059669",
    IRN: "#D97706", EWayBill: "#DC2626", Return: "#0891B2", TaxPayment: "#BE185D"
  };

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext("2d");
    const W = canvas.width, H = canvas.height;

    // Init nodes with force-directed positions
    const nodeList = nodes_sample.map((n, i) => ({
      ...n, id: n.id,
      x: 80 + Math.random() * (W - 160),
      y: 80 + Math.random() * (H - 160),
      vx: 0, vy: 0,
      r: n.type === "Invoice" ? 6 : n.type === "GSTIN" ? 9 : n.type === "Taxpayer" ? 12 : 5,
      color: TYPE_COLORS[n.type] || "#666"
    }));

    const nodeMap = {};
    nodeList.forEach(n => nodeMap[n.id] = n);

    const edgeList = edges_sample.map(e => ({
      ...e, source: nodeMap[e.source], target: nodeMap[e.target]
    })).filter(e => e.source && e.target);

    nodesRef.current = nodeList;
    edgesRef.current = edgeList;

    let frame = 0;
    const animate = () => {
      frame++;
      // Simple force simulation
      nodeList.forEach(n => {
        // Repulsion
        nodeList.forEach(m => {
          if (n === m) return;
          const dx = n.x - m.x, dy = n.y - m.y;
          const d = Math.sqrt(dx * dx + dy * dy) || 1;
          if (d < 80) {
            const f = 200 / (d * d);
            n.vx += dx * f * 0.5;
            n.vy += dy * f * 0.5;
          }
        });
        // Center gravity
        n.vx += (W / 2 - n.x) * 0.001;
        n.vy += (H / 2 - n.y) * 0.001;
        // Damping
        n.vx *= 0.85; n.vy *= 0.85;
        n.x += n.vx; n.y += n.vy;
        n.x = Math.max(n.r + 5, Math.min(W - n.r - 5, n.x));
        n.y = Math.max(n.r + 5, Math.min(H - n.r - 5, n.y));
      });

      // Spring attraction
      edgeList.forEach(e => {
        if (!e.source || !e.target) return;
        const dx = e.target.x - e.source.x, dy = e.target.y - e.source.y;
        const d = Math.sqrt(dx * dx + dy * dy) || 1;
        const f = (d - 60) * 0.003;
        e.source.vx += dx * f; e.source.vy += dy * f;
        e.target.vx -= dx * f; e.target.vy -= dy * f;
      });

      ctx.clearRect(0, 0, W, H);

      // Draw edges
      edgeList.forEach(e => {
        if (!e.source || !e.target) return;
        ctx.beginPath();
        ctx.moveTo(e.source.x, e.source.y);
        ctx.lineTo(e.target.x, e.target.y);
        ctx.strokeStyle = "rgba(255,255,255,0.06)";
        ctx.lineWidth = 0.8;
        ctx.stroke();
      });

      // Draw nodes
      nodeList.forEach(n => {
        ctx.beginPath();
        ctx.arc(n.x, n.y, n.r, 0, Math.PI * 2);
        ctx.fillStyle = n.color + (frame % 60 < 30 ? "CC" : "AA");
        ctx.fill();
        ctx.strokeStyle = n.color + "88";
        ctx.lineWidth = 1.5;
        ctx.stroke();

        // Pulse for mismatched nodes
        if (n.type === "Invoice" && Math.random() < 0.001) {
          ctx.beginPath();
          ctx.arc(n.x, n.y, n.r + 6, 0, Math.PI * 2);
          ctx.strokeStyle = "#FF2D5540";
          ctx.lineWidth = 1;
          ctx.stroke();
        }
      });

      animRef.current = requestAnimationFrame(animate);
    };

    animate();
    return () => cancelAnimationFrame(animRef.current);
  }, []);

  const LEGEND = Object.entries({ Taxpayer: "#7C3AED", GSTIN: "#2563EB", Invoice: "#059669", IRN: "#D97706", "E-Way Bill": "#DC2626", Return: "#0891B2" });

  return (
    <div style={{ position: "relative" }}>
      <canvas ref={canvasRef} width={680} height={320}
        style={{ width: "100%", height: 320, borderRadius: 12, background: "rgba(0,0,0,0.4)", cursor: "crosshair" }} />
      <div style={{ position: "absolute", bottom: 12, left: 12, display: "flex", gap: 12, flexWrap: "wrap" }}>
        {LEGEND.map(([type, color]) => (
          <div key={type} style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 10, color: "#aaa" }}>
            <div style={{ width: 8, height: 8, borderRadius: "50%", background: color }} />
            {type}
          </div>
        ))}
      </div>
      <div style={{ position: "absolute", top: 12, right: 12, fontSize: 10, color: "#555", fontFamily: "mono" }}>
        {SUMMARY.graph_stats.total_nodes} nodes · {SUMMARY.graph_stats.total_edges} edges
      </div>
    </div>
  );
}

function MismatchTable({ mismatches, onSelect, selected }) {
  return (
    <div style={{ overflowX: "auto" }}>
      <table style={{ width: "100%", borderCollapse: "collapse", fontSize: 13 }}>
        <thead>
          <tr>
            {["ID", "Type", "Risk", "Supplier GSTIN", "Variance", "ITC at Risk", ""].map(h => (
              <th key={h} style={{ padding: "10px 12px", textAlign: "left", borderBottom: "1px solid #222", color: "#666", fontSize: 11, fontFamily: "mono", letterSpacing: "0.08em", fontWeight: 500, background: "rgba(0,0,0,0.3)" }}>{h}</th>
            ))}
          </tr>
        </thead>
        <tbody>
          {mismatches.map(m => (
            <tr key={m.mismatch_id}
              onClick={() => onSelect(m)}
              style={{
                background: selected?.mismatch_id === m.mismatch_id ? "rgba(99,102,241,0.12)" : "transparent",
                cursor: "pointer", transition: "background 0.15s",
                borderBottom: "1px solid rgba(255,255,255,0.04)"
              }}
              onMouseEnter={e => { if (selected?.mismatch_id !== m.mismatch_id) e.currentTarget.style.background = "rgba(255,255,255,0.03)"; }}
              onMouseLeave={e => { if (selected?.mismatch_id !== m.mismatch_id) e.currentTarget.style.background = "transparent"; }}
            >
              <td style={{ padding: "11px 12px", fontFamily: "mono", fontSize: 11, color: "#6366f1" }}>{m.mismatch_id}</td>
              <td style={{ padding: "11px 12px" }}>
                <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <span>{MTYPE_ICONS[m.mismatch_type]}</span>
                  <span style={{ color: "#ccc" }}>{m.mismatch_type}</span>
                </span>
              </td>
              <td style={{ padding: "11px 12px" }}><RiskBadge level={m.risk_level} /></td>
              <td style={{ padding: "11px 12px", fontFamily: "mono", fontSize: 11, color: "#aaa" }}>{m.supplier_gstin.slice(0, 15)}</td>
              <td style={{ padding: "11px 12px", color: RISK_COLORS[m.risk_level]?.text || "#fff", fontFamily: "mono", fontSize: 12 }}>
                {fmtL(m.variance)}
              </td>
              <td style={{ padding: "11px 12px", color: "#FF2D55", fontWeight: 600, fontFamily: "mono", fontSize: 12 }}>
                {fmtL(m.itc_at_risk)}
              </td>
              <td style={{ padding: "11px 12px", color: "#6366f1", fontSize: 16 }}>›</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}

function AuditPanel({ mismatch }) {
  if (!mismatch) return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center", justifyContent: "center", height: "100%", color: "#444", gap: 12 }}>
      <div style={{ fontSize: 40 }}>🔍</div>
      <div style={{ fontSize: 13 }}>Select a mismatch to view audit trail</div>
    </div>
  );

  const NL_EXPLANATIONS = {
    "Missing in GSTR-2B": `Supplier ${mismatch.supplier_gstin} has not filed their GSTR-1 for 01/2024. As a result, the invoice does not appear in buyer ${mismatch.buyer_gstin}'s GSTR-2B, making ₹${fmt(mismatch.itc_at_risk)} of Input Tax Credit ineligible under Rule 36(4). The buyer should follow up with the supplier and defer this ITC claim until compliance is achieved.`,
    "Duplicate Invoice": `The same invoice from supplier ${mismatch.supplier_gstin} appears to have been claimed twice in buyer ${mismatch.buyer_gstin}'s returns. This constitutes a duplicate ITC claim of ₹${fmt(mismatch.itc_at_risk)} and must be reversed immediately to avoid penalties under Section 74 of the CGST Act, 2017.`,
    "IRN Not Found": `Invoice from supplier ${mismatch.supplier_gstin} to buyer ${mismatch.buyer_gstin} has a taxable value exceeding the e-Invoice threshold but no IRN is registered with the IRP. This is a strong indicator of a potentially fraudulent or fabricated invoice. ITC of ₹${fmt(mismatch.itc_at_risk)} is at risk and an immediate investigation is recommended.`,
    "Amount Mismatch": `For the period 01/2024, supplier ${mismatch.supplier_gstin} reported a lower tax amount in their GSTR-1 compared to what appears in the buyer's purchase register. The variance of ₹${fmt(mismatch.variance)} results in ₹${fmt(mismatch.itc_at_risk)} of ITC being at risk. The supplier must file an amendment return (GSTR-1A) to correct the discrepancy.`,
    "E-Way Bill Mismatch": `The E-Way Bill value for the invoice from ${mismatch.supplier_gstin} to ${mismatch.buyer_gstin} is significantly lower than the invoice value, creating a variance of ₹${fmt(mismatch.variance)}. This discrepancy may indicate under-declaration of goods value. Physical movement verification and transporter records should be reviewed.`,
  };

  return (
    <div style={{ padding: "0 4px" }}>
      <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 20 }}>
        <div style={{ fontSize: 24 }}>{MTYPE_ICONS[mismatch.mismatch_type]}</div>
        <div>
          <div style={{ fontSize: 13, fontWeight: 600, color: "#fff" }}>{mismatch.mismatch_type}</div>
          <div style={{ fontSize: 11, color: "#666", fontFamily: "mono" }}>{mismatch.mismatch_id}</div>
        </div>
        <div style={{ marginLeft: "auto" }}><RiskBadge level={mismatch.risk_level} /></div>
      </div>

      {/* Financial Impact */}
      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10, marginBottom: 20 }}>
        <div style={{ background: "rgba(255,45,85,0.08)", border: "1px solid rgba(255,45,85,0.2)", borderRadius: 10, padding: "12px 16px" }}>
          <div style={{ fontSize: 10, color: "#FF2D5599", marginBottom: 4, letterSpacing: "0.1em" }}>ITC AT RISK</div>
          <div style={{ fontSize: 20, fontWeight: 700, color: "#FF2D55", fontFamily: "Syne" }}>{fmtL(mismatch.itc_at_risk)}</div>
        </div>
        <div style={{ background: "rgba(255,149,0,0.08)", border: "1px solid rgba(255,149,0,0.2)", borderRadius: 10, padding: "12px 16px" }}>
          <div style={{ fontSize: 10, color: "#FF950099", marginBottom: 4, letterSpacing: "0.1em" }}>VARIANCE</div>
          <div style={{ fontSize: 20, fontWeight: 700, color: "#FF9500", fontFamily: "Syne" }}>{mismatch.variance_pct}%</div>
        </div>
      </div>

      {/* NL Explanation */}
      <div style={{ background: "rgba(99,102,241,0.08)", border: "1px solid rgba(99,102,241,0.2)", borderRadius: 10, padding: 14, marginBottom: 16 }}>
        <div style={{ fontSize: 10, color: "#6366f1", marginBottom: 8, letterSpacing: "0.1em" }}>🤖 AI AUDIT EXPLANATION</div>
        <div style={{ fontSize: 12, color: "#bbb", lineHeight: 1.7 }}>
          {NL_EXPLANATIONS[mismatch.mismatch_type] || mismatch.root_cause}
        </div>
      </div>

      {/* Audit Trail */}
      <div style={{ marginBottom: 16 }}>
        <div style={{ fontSize: 10, color: "#666", marginBottom: 10, letterSpacing: "0.1em" }}>GRAPH TRAVERSAL AUDIT TRAIL</div>
        {mismatch.audit_trail.map((step, i) => (
          <div key={i} style={{ display: "flex", gap: 10, marginBottom: 8 }}>
            <div style={{ width: 20, height: 20, borderRadius: "50%", background: i === mismatch.audit_trail.length - 1 ? "#FF2D55" : "#6366f1", display: "flex", alignItems: "center", justifyContent: "center", fontSize: 9, color: "#fff", flexShrink: 0, marginTop: 1 }}>{i + 1}</div>
            <div style={{ fontSize: 11, color: "#aaa", lineHeight: 1.6 }}>{step.replace(/\[STEP \d+\] /, "")}</div>
          </div>
        ))}
      </div>

      {/* Recommendation */}
      <div style={{ background: "rgba(52,199,89,0.08)", border: "1px solid rgba(52,199,89,0.2)", borderRadius: 10, padding: 14 }}>
        <div style={{ fontSize: 10, color: "#34C759", marginBottom: 6, letterSpacing: "0.1em" }}>✅ RECOMMENDATION</div>
        <div style={{ fontSize: 12, color: "#bbb", lineHeight: 1.6 }}>{mismatch.recommendation}</div>
      </div>
    </div>
  );
}

function ITCChainViewer() {
  const chain = ITC_CHAIN;
  const hops = chain.hops;

  return (
    <div>
      <div style={{ display: "flex", gap: 16, marginBottom: 20, flexWrap: "wrap" }}>
        <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: "10px 16px", flex: 1, minWidth: 140 }}>
          <div style={{ fontSize: 10, color: "#666", marginBottom: 4 }}>INVOICE</div>
          <div style={{ fontSize: 11, color: "#aaa", fontFamily: "mono" }}>{chain.invoice_data.invoice_no}</div>
        </div>
        <div style={{ background: "rgba(255,255,255,0.04)", borderRadius: 10, padding: "10px 16px", flex: 1, minWidth: 140 }}>
          <div style={{ fontSize: 10, color: "#666", marginBottom: 4 }}>TAXABLE VALUE</div>
          <div style={{ fontSize: 13, color: "#fff", fontWeight: 600 }}>{fmtCr(chain.invoice_data.taxable_value)}</div>
        </div>
        <div style={{ background: "rgba(255,45,85,0.08)", border: "1px solid rgba(255,45,85,0.2)", borderRadius: 10, padding: "10px 16px", flex: 1, minWidth: 140 }}>
          <div style={{ fontSize: 10, color: "#FF2D5580", marginBottom: 4 }}>ITC AT RISK</div>
          <div style={{ fontSize: 13, color: "#FF2D55", fontWeight: 700 }}>{fmtL(chain.invoice_data.total_tax)}</div>
        </div>
      </div>

      <div style={{ display: "flex", alignItems: "center", gap: 0, overflowX: "auto", padding: "10px 0" }}>
        {hops.map((hop, i) => {
          const isOk = hop.status.startsWith("✅");
          const isPending = hop.status.startsWith("⏳");
          const isBad = hop.status.startsWith("❌") || hop.status.startsWith("⚠️");
          const color = isOk ? "#34C759" : isBad ? "#FF2D55" : "#FF9500";

          return (
            <div key={hop.hop} style={{ display: "flex", alignItems: "center" }}>
              <div style={{
                background: `rgba(${isOk ? "52,199,89" : isBad ? "255,45,85" : "255,149,0"},0.1)`,
                border: `1px solid ${color}40`,
                borderRadius: 12, padding: "14px 16px", minWidth: 120, textAlign: "center",
                position: "relative"
              }}>
                <div style={{ fontSize: 18, marginBottom: 4 }}>{hop.status.split(" ")[0]}</div>
                <div style={{ fontSize: 10, color, fontWeight: 600, marginBottom: 2 }}>HOP {hop.hop}</div>
                <div style={{ fontSize: 11, color: "#bbb" }}>{hop.name}</div>
                <div style={{ fontSize: 10, color: color + "aa", marginTop: 4 }}>
                  {hop.status.split(" ").slice(1).join(" ")}
                </div>
              </div>
              {i < hops.length - 1 && (
                <div style={{ width: 30, height: 2, background: `linear-gradient(90deg, ${color}60, ${(hops[i + 1].status.startsWith("✅") ? "#34C759" : "#FF2D55")}60)`, flexShrink: 0 }} />
              )}
            </div>
          );
        })}
      </div>

      {!chain.is_valid && (
        <div style={{ marginTop: 16, background: "rgba(255,45,85,0.08)", border: "1px solid rgba(255,45,85,0.3)", borderRadius: 10, padding: 14 }}>
          <div style={{ fontSize: 11, color: "#FF2D55", fontWeight: 600 }}>⚡ ITC Chain Broken At:</div>
          <div style={{ fontSize: 12, color: "#aaa", marginTop: 4 }}>{chain.broken_at}</div>
        </div>
      )}
    </div>
  );
}

function VendorScoreboard({ vendors }) {
  const maxRisk = Math.max(...vendors.map(v => v.risk_score));

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
      {vendors.map(v => {
        const riskColor = v.risk_score >= 70 ? "#FF2D55" : v.risk_score >= 45 ? "#FF9500" : "#34C759";
        const compColor = v.compliance_score >= 80 ? "#34C759" : v.compliance_score >= 60 ? "#FF9500" : "#FF2D55";
        return (
          <div key={v.gstin} style={{
            background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)",
            borderRadius: 12, padding: "14px 18px",
            transition: "all 0.2s"
          }}
          onMouseEnter={e => e.currentTarget.style.background = "rgba(255,255,255,0.05)"}
          onMouseLeave={e => e.currentTarget.style.background = "rgba(255,255,255,0.02)"}
          >
            <div style={{ display: "flex", alignItems: "flex-start", gap: 12, marginBottom: 10 }}>
              <div style={{ flex: 1 }}>
                <div style={{ fontSize: 13, color: "#ddd", fontWeight: 600, marginBottom: 2 }}>{v.legal_name}</div>
                <div style={{ fontSize: 10, color: "#666", fontFamily: "mono" }}>{v.gstin} · {v.state} · {v.sector}</div>
              </div>
              <div style={{ textAlign: "right" }}>
                <div style={{ fontSize: 11, color: "#666", marginBottom: 2 }}>ITC at Risk</div>
                <div style={{ fontSize: 14, color: "#FF2D55", fontWeight: 700, fontFamily: "mono" }}>{fmtL(v.itc_at_risk)}</div>
              </div>
            </div>

            <div style={{ display: "flex", gap: 12, marginBottom: 10 }}>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: 10, color: "#666" }}>
                  <span>Risk Score</span><span style={{ color: riskColor, fontWeight: 600 }}>{v.risk_score}</span>
                </div>
                <div style={{ height: 4, background: "#111", borderRadius: 2, overflow: "hidden" }}>
                  <div style={{ width: `${v.risk_score}%`, height: "100%", background: riskColor, borderRadius: 2, transition: "width 0.5s" }} />
                </div>
              </div>
              <div style={{ flex: 1 }}>
                <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 4, fontSize: 10, color: "#666" }}>
                  <span>Compliance</span><span style={{ color: compColor, fontWeight: 600 }}>{v.compliance_score}</span>
                </div>
                <div style={{ height: 4, background: "#111", borderRadius: 2, overflow: "hidden" }}>
                  <div style={{ width: `${v.compliance_score}%`, height: "100%", background: compColor, borderRadius: 2, transition: "width 0.5s" }} />
                </div>
              </div>
            </div>

            <div style={{ display: "flex", gap: 8 }}>
              <span style={{ fontSize: 10, color: "#666" }}>{v.mismatch_count} mismatches · {v.mismatch_rate}% rate</span>
              <span style={{ marginLeft: "auto", fontSize: 10,
                color: v.status === "Non-Compliant" ? "#FF2D55" : v.status === "At Risk" ? "#FF9500" : "#34C759"
              }}>{v.status}</span>
            </div>
          </div>
        );
      })}
    </div>
  );
}

// ─────────────────────────────────────────────────────────────────────────────
// MAIN APP
// ─────────────────────────────────────────────────────────────────────────────

export default function GSTReconciliationDashboard() {
  const [activeTab, setActiveTab] = useState("overview");
  const [selectedMismatch, setSelectedMismatch] = useState(MISMATCHES[0]);
  const [filterRisk, setFilterRisk] = useState("ALL");
  const [mounted, setMounted] = useState(false);

  useEffect(() => { setTimeout(() => setMounted(true), 100); }, []);

  const filteredMismatches = filterRisk === "ALL"
    ? MISMATCHES
    : MISMATCHES.filter(m => m.risk_level === filterRisk);

  const donutData = [
    { label: "Missing in 2B", value: 8, color: "#FF2D55" },
    { label: "IRN Not Found", value: 7, color: "#FF9500" },
    { label: "Duplicate", value: 6, color: "#FFCC00" },
    { label: "Amount Mismatch", value: 5, color: "#6366f1" },
    { label: "EWB Mismatch", value: 3, color: "#34C759" },
  ];

  const TABS = [
    { id: "overview", label: "Overview", icon: "◉" },
    { id: "mismatches", label: "Mismatches", icon: "⚠" },
    { id: "graph", label: "Knowledge Graph", icon: "◎" },
    { id: "itc", label: "ITC Chain", icon: "⛓" },
    { id: "vendors", label: "Vendor Risk", icon: "⬡" },
  ];

  // Sample graph nodes for visualization
  const graphNodes = [
    ...Array(8).fill(null).map((_, i) => ({ id: `TP_${i}`, type: "Taxpayer" })),
    ...Array(12).fill(null).map((_, i) => ({ id: `GST_${i}`, type: "GSTIN" })),
    ...Array(30).fill(null).map((_, i) => ({ id: `INV_${i}`, type: "Invoice" })),
    ...Array(20).fill(null).map((_, i) => ({ id: `IRN_${i}`, type: "IRN" })),
    ...Array(15).fill(null).map((_, i) => ({ id: `EWB_${i}`, type: "EWayBill" })),
    ...Array(12).fill(null).map((_, i) => ({ id: `RET_${i}`, type: "Return" })),
  ];
  const graphEdges = [
    ...Array(12).fill(null).map((_, i) => ({ source: `TP_${Math.floor(i / 2)}`, target: `GST_${i}`, type: "HAS_GSTIN" })),
    ...Array(30).fill(null).map((_, i) => ({ source: `INV_${i}`, target: `GST_${Math.floor(Math.random() * 12)}`, type: "ISSUED_BY" })),
    ...Array(20).fill(null).map((_, i) => ({ source: `INV_${i}`, target: `IRN_${i}`, type: "HAS_IRN" })),
    ...Array(15).fill(null).map((_, i) => ({ source: `INV_${i}`, target: `EWB_${i}`, type: "HAS_EWBILL" })),
  ];

  return (
    <div style={{
      minHeight: "100vh", background: "#090912",
      fontFamily: "'Inter', -apple-system, sans-serif",
      color: "#e0e0e8",
    }}>
      <style>{`
        @import url('https://fonts.googleapis.com/css2?family=Syne:wght@400;600;700;800&family=JetBrains+Mono:wght@400;600&display=swap');
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 6px; height: 6px; }
        ::-webkit-scrollbar-track { background: #111; }
        ::-webkit-scrollbar-thumb { background: #333; border-radius: 3px; }
        body { margin: 0; }
        .tab-btn { transition: all 0.2s; }
        .tab-btn:hover { background: rgba(255,255,255,0.06) !important; }
      `}</style>

      {/* Header */}
      <div style={{
        background: "rgba(0,0,0,0.6)", backdropFilter: "blur(20px)",
        borderBottom: "1px solid rgba(255,255,255,0.06)",
        padding: "16px 32px", display: "flex", alignItems: "center", gap: 20,
        position: "sticky", top: 0, zIndex: 100
      }}>
        <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
          <div style={{ width: 36, height: 36, background: "linear-gradient(135deg, #6366f1, #8b5cf6)", borderRadius: 10, display: "flex", alignItems: "center", justifyContent: "center", fontSize: 16 }}>◎</div>
          <div>
            <div style={{ fontSize: 16, fontWeight: 700, fontFamily: "Syne", letterSpacing: "-0.02em", color: "#fff" }}>GST Reconciliation Engine</div>
            <div style={{ fontSize: 11, color: "#555", fontFamily: "monospace" }}>Knowledge Graph · AI-Powered · Period: Jan 2024</div>
          </div>
        </div>

        <div style={{ flex: 1 }} />

        <div style={{ display: "flex", gap: 16, alignItems: "center" }}>
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 10, color: "#555" }}>ITC AT RISK</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#FF2D55", fontFamily: "Syne" }}>{fmtCr(SUMMARY.total_itc_at_risk)}</div>
          </div>
          <div style={{ width: 1, height: 32, background: "#222" }} />
          <div style={{ textAlign: "right" }}>
            <div style={{ fontSize: 10, color: "#555" }}>RECONCILED</div>
            <div style={{ fontSize: 18, fontWeight: 700, color: "#34C759", fontFamily: "Syne" }}>{SUMMARY.reconciliation_rate}%</div>
          </div>
          <div style={{ background: "rgba(255,45,85,0.15)", border: "1px solid rgba(255,45,85,0.3)", borderRadius: 8, padding: "6px 14px", fontSize: 12, color: "#FF2D55", fontWeight: 600 }}>
            {SUMMARY.critical_mismatches} CRITICAL
          </div>
        </div>
      </div>

      {/* Tab Navigation */}
      <div style={{ borderBottom: "1px solid rgba(255,255,255,0.06)", padding: "0 32px", display: "flex", gap: 4 }}>
        {TABS.map(tab => (
          <button key={tab.id} className="tab-btn"
            onClick={() => setActiveTab(tab.id)}
            style={{
              background: activeTab === tab.id ? "rgba(99,102,241,0.12)" : "transparent",
              border: "none", borderBottom: activeTab === tab.id ? "2px solid #6366f1" : "2px solid transparent",
              padding: "14px 20px", cursor: "pointer", color: activeTab === tab.id ? "#6366f1" : "#666",
              fontSize: 13, fontWeight: activeTab === tab.id ? 600 : 400, fontFamily: "inherit",
              display: "flex", alignItems: "center", gap: 7, transition: "all 0.2s"
            }}
          >
            <span style={{ fontSize: 14 }}>{tab.icon}</span>{tab.label}
          </button>
        ))}
      </div>

      {/* Content */}
      <div style={{ padding: "28px 32px", maxWidth: 1400, margin: "0 auto" }}>

        {/* OVERVIEW TAB */}
        {activeTab === "overview" && (
          <div style={{ opacity: mounted ? 1 : 0, transition: "opacity 0.4s" }}>
            {/* KPI Grid */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit, minmax(200px, 1fr))", gap: 16, marginBottom: 28 }}>
              <KPICard label="Total Taxpayers" value={SUMMARY.total_taxpayers} sub="Active GSTINs" accent="#6366f1" icon="🏢" />
              <KPICard label="Invoices Processed" value={fmt(SUMMARY.total_invoices)} sub={`${SUMMARY.total_irns} with IRN`} accent="#2563EB" icon="📄" />
              <KPICard label="Total ITC Pool" value={fmtCr(SUMMARY.total_itc_pool)} sub="Jan 2024" accent="#059669" icon="💰" />
              <KPICard label="ITC at Risk" value={fmtCr(SUMMARY.total_itc_at_risk)} sub={`${SUMMARY.itc_leakage_pct}% leakage`} accent="#FF2D55" icon="⚠️" />
              <KPICard label="Mismatches Found" value={SUMMARY.total_mismatches} sub={`${SUMMARY.critical_mismatches} critical`} accent="#FF9500" icon="🔍" />
              <KPICard label="Graph Nodes" value={fmt(SUMMARY.graph_stats.total_nodes)} sub={`${fmt(SUMMARY.graph_stats.total_edges)} edges`} accent="#8b5cf6" icon="◎" />
            </div>

            {/* Two column layout */}
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20, marginBottom: 20 }}>
              {/* Mismatch breakdown */}
              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", marginBottom: 20, letterSpacing: "0.05em" }}>MISMATCH BREAKDOWN</div>
                <div style={{ display: "flex", alignItems: "center", gap: 20 }}>
                  <MismatchDonut data={donutData} />
                  <div style={{ flex: 1, display: "flex", flexDirection: "column", gap: 10 }}>
                    {donutData.map(d => (
                      <div key={d.label} style={{ display: "flex", alignItems: "center", gap: 10 }}>
                        <div style={{ width: 10, height: 10, borderRadius: 2, background: d.color, flexShrink: 0 }} />
                        <div style={{ flex: 1, fontSize: 12, color: "#999" }}>{d.label}</div>
                        <div style={{ fontSize: 12, fontWeight: 600, color: "#ccc", fontFamily: "mono" }}>{d.value}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>

              {/* Node type breakdown */}
              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", marginBottom: 20, letterSpacing: "0.05em" }}>KNOWLEDGE GRAPH ENTITIES</div>
                {Object.entries(SUMMARY.graph_stats.node_types).map(([type, count]) => {
                  const colors = { Taxpayer: "#7C3AED", GSTIN: "#2563EB", Invoice: "#059669", IRN: "#D97706", EWayBill: "#DC2626", Return: "#0891B2", TaxPayment: "#BE185D" };
                  const maxCount = Math.max(...Object.values(SUMMARY.graph_stats.node_types));
                  return (
                    <div key={type} style={{ marginBottom: 12 }}>
                      <div style={{ display: "flex", justifyContent: "space-between", marginBottom: 5, fontSize: 12 }}>
                        <span style={{ color: "#999" }}>{type}</span>
                        <span style={{ color: colors[type] || "#aaa", fontFamily: "mono", fontWeight: 600 }}>{count}</span>
                      </div>
                      <div style={{ height: 5, background: "#1a1a2e", borderRadius: 3, overflow: "hidden" }}>
                        <div style={{ width: `${count / maxCount * 100}%`, height: "100%", background: colors[type] || "#666", borderRadius: 3, transition: "width 0.8s ease" }} />
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            {/* Quick mismatch preview */}
            <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", letterSpacing: "0.05em" }}>TOP CRITICAL MISMATCHES</div>
                <button onClick={() => setActiveTab("mismatches")} style={{ background: "rgba(99,102,241,0.15)", border: "1px solid rgba(99,102,241,0.3)", borderRadius: 8, padding: "6px 14px", color: "#6366f1", fontSize: 12, cursor: "pointer", fontFamily: "inherit" }}>View All →</button>
              </div>
              <MismatchTable mismatches={MISMATCHES.filter(m => m.risk_level === "CRITICAL").slice(0, 4)} onSelect={setSelectedMismatch} selected={selectedMismatch} />
            </div>
          </div>
        )}

        {/* MISMATCHES TAB */}
        {activeTab === "mismatches" && (
          <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 20, height: "calc(100vh - 200px)" }}>
            <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, display: "flex", flexDirection: "column", overflow: "hidden" }}>
              <div style={{ padding: "18px 20px", borderBottom: "1px solid rgba(255,255,255,0.06)", display: "flex", gap: 10, alignItems: "center" }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa" }}>RECONCILIATION MISMATCHES</div>
                <div style={{ flex: 1 }} />
                {["ALL", "CRITICAL", "HIGH", "MEDIUM"].map(r => (
                  <button key={r} onClick={() => setFilterRisk(r)}
                    style={{
                      background: filterRisk === r ? (r === "ALL" ? "rgba(99,102,241,0.2)" : `${RISK_COLORS[r]?.badge || "rgba(99,102,241,0.2)"}`) : "rgba(255,255,255,0.04)",
                      border: filterRisk === r ? `1px solid ${RISK_COLORS[r]?.border || "rgba(99,102,241,0.4)"}` : "1px solid rgba(255,255,255,0.08)",
                      borderRadius: 8, padding: "5px 12px", cursor: "pointer",
                      color: filterRisk === r ? (RISK_COLORS[r]?.text || "#6366f1") : "#666",
                      fontSize: 11, fontFamily: "inherit", fontWeight: filterRisk === r ? 700 : 400
                    }}>{r}</button>
                ))}
              </div>
              <div style={{ flex: 1, overflowY: "auto" }}>
                <MismatchTable mismatches={filteredMismatches} onSelect={setSelectedMismatch} selected={selectedMismatch} />
              </div>
            </div>
            <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 20, overflowY: "auto" }}>
              <div style={{ fontSize: 12, fontWeight: 600, color: "#666", marginBottom: 16, letterSpacing: "0.08em" }}>AUDIT DETAIL</div>
              <AuditPanel mismatch={selectedMismatch} />
            </div>
          </div>
        )}

        {/* GRAPH TAB */}
        {activeTab === "graph" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4,1fr)", gap: 16 }}>
              {[
                { label: "Total Nodes", value: SUMMARY.graph_stats.total_nodes, color: "#6366f1" },
                { label: "Total Edges", value: SUMMARY.graph_stats.total_edges, color: "#2563EB" },
                { label: "Graph Density", value: SUMMARY.graph_stats.density, color: "#059669" },
                { label: "Relationship Types", value: Object.keys(SUMMARY.graph_stats.relationship_types).length, color: "#D97706" },
              ].map(s => (
                <div key={s.label} style={{ background: "rgba(255,255,255,0.03)", border: `1px solid ${s.color}30`, borderRadius: 12, padding: 18, textAlign: "center" }}>
                  <div style={{ fontSize: 24, fontWeight: 800, color: s.color, fontFamily: "Syne" }}>{s.value}</div>
                  <div style={{ fontSize: 11, color: "#666", marginTop: 4 }}>{s.label}</div>
                </div>
              ))}
            </div>

            <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", marginBottom: 16, letterSpacing: "0.05em" }}>LIVE KNOWLEDGE GRAPH VISUALIZATION</div>
              <GraphViz nodes_sample={graphNodes} edges_sample={graphEdges} />
              <div style={{ marginTop: 12, fontSize: 11, color: "#555", textAlign: "center" }}>Force-directed graph · Nodes auto-arrange by relationship topology</div>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", marginBottom: 16 }}>NODE TYPES</div>
                {Object.entries(SUMMARY.graph_stats.node_types).map(([k, v]) => (
                  <div key={k} style={{ display: "flex", justifyContent: "space-between", padding: "8px 0", borderBottom: "1px solid rgba(255,255,255,0.04)", fontSize: 13 }}>
                    <span style={{ color: "#aaa" }}>{k}</span>
                    <span style={{ color: "#6366f1", fontFamily: "mono", fontWeight: 600 }}>{v}</span>
                  </div>
                ))}
              </div>
              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", marginBottom: 16 }}>GRAPH SCHEMA (Cypher-style)</div>
                <div style={{ fontFamily: "JetBrains Mono, monospace", fontSize: 11, color: "#888", lineHeight: 1.9 }}>
                  {[
                    ["(Taxpayer)", "HAS_GSTIN", "(GSTIN)", "#7C3AED"],
                    ["(Invoice)", "ISSUED_BY", "(GSTIN)", "#2563EB"],
                    ["(Invoice)", "HAS_IRN", "(IRN)", "#D97706"],
                    ["(Invoice)", "HAS_EWBILL", "(EWayBill)", "#DC2626"],
                    ["(Invoice)", "REPORTED_IN", "(Return)", "#0891B2"],
                    ["(Return)", "PAID_VIA", "(TaxPayment)", "#BE185D"],
                  ].map(([a, r, b, c]) => (
                    <div key={r} style={{ marginBottom: 4 }}>
                      <span style={{ color: "#6366f1" }}>{a}</span>
                      <span style={{ color: "#555" }}> -[</span>
                      <span style={{ color: c }}>{r}</span>
                      <span style={{ color: "#555" }}>]→ </span>
                      <span style={{ color: "#6366f1" }}>{b}</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ITC CHAIN TAB */}
        {activeTab === "itc" && (
          <div style={{ display: "flex", flexDirection: "column", gap: 20 }}>
            <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
              <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", marginBottom: 6, letterSpacing: "0.05em" }}>MULTI-HOP ITC VALIDATION CHAIN</div>
              <div style={{ fontSize: 12, color: "#555", marginBottom: 20 }}>Graph traversal: Invoice → IRN → E-Way Bill → GSTR-1 → GSTR-2B → GSTR-3B → Payment</div>
              <ITCChainViewer />
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 20 }}>
              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", marginBottom: 16 }}>ITC VALIDATION RULES</div>
                {[
                  ["Rule 36(4)", "ITC restricted if supplier GSTR-1 unpaid", "CRITICAL"],
                  ["Section 16(2)(aa)", "ITC only on GSTR-2B reflected invoices", "HIGH"],
                  ["Rule 86B", "1% cash payment for high-value suppliers", "MEDIUM"],
                  ["Section 17(5)", "Blocked credits — construction, food etc.", "HIGH"],
                  ["Section 74", "Penalty for duplicate/fraudulent claims", "CRITICAL"],
                ].map(([rule, desc, risk]) => (
                  <div key={rule} style={{ display: "flex", gap: 12, padding: "10px 0", borderBottom: "1px solid rgba(255,255,255,0.04)" }}>
                    <div style={{ fontSize: 11, fontFamily: "mono", color: "#6366f1", width: 90, flexShrink: 0, paddingTop: 1 }}>{rule}</div>
                    <div style={{ fontSize: 12, color: "#999", flex: 1 }}>{desc}</div>
                    <RiskBadge level={risk} />
                  </div>
                ))}
              </div>

              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", marginBottom: 16 }}>ITC LEAKAGE SUMMARY</div>
                {[
                  { type: "Missing in GSTR-2B", amount: 3240000, pct: 37.6 },
                  { type: "Duplicate Claims", amount: 2178000, pct: 25.2 },
                  { type: "IRN Fraud", amount: 1850000, pct: 21.5 },
                  { type: "Amount Mismatches", amount: 890000, pct: 10.3 },
                  { type: "EWB Discrepancies", amount: 468000, pct: 5.4 },
                ].map(item => (
                  <div key={item.type} style={{ marginBottom: 14 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 6 }}>
                      <span style={{ color: "#999" }}>{item.type}</span>
                      <span style={{ color: "#FF2D55", fontFamily: "mono", fontWeight: 600 }}>{fmtL(item.amount)}</span>
                    </div>
                    <div style={{ height: 6, background: "#1a1a2e", borderRadius: 3, overflow: "hidden" }}>
                      <div style={{ width: `${item.pct}%`, height: "100%", background: "linear-gradient(90deg, #FF2D55, #FF9500)", borderRadius: 3 }} />
                    </div>
                    <div style={{ fontSize: 10, color: "#555", marginTop: 3 }}>{item.pct}% of total leakage</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

        {/* VENDORS TAB */}
        {activeTab === "vendors" && (
          <div style={{ display: "grid", gridTemplateColumns: "2fr 1fr", gap: 20 }}>
            <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
              <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                <div>
                  <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", letterSpacing: "0.05em" }}>VENDOR COMPLIANCE RISK SCORES</div>
                  <div style={{ fontSize: 11, color: "#555", marginTop: 4 }}>Ranked by composite risk (mismatch rate + compliance history + ITC leakage)</div>
                </div>
                <div style={{ background: "rgba(255,45,85,0.12)", border: "1px solid rgba(255,45,85,0.25)", borderRadius: 10, padding: "8px 14px", textAlign: "center" }}>
                  <div style={{ fontSize: 20, color: "#FF2D55", fontWeight: 700, fontFamily: "Syne" }}>{VENDORS.filter(v => v.risk_score >= 60).length}</div>
                  <div style={{ fontSize: 10, color: "#FF2D5580" }}>HIGH RISK</div>
                </div>
              </div>
              <VendorScoreboard vendors={VENDORS} />
            </div>

            <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", marginBottom: 16 }}>PREDICTIVE RISK MODEL</div>
                <div style={{ fontSize: 11, color: "#555", marginBottom: 16, lineHeight: 1.7 }}>
                  Graph-based ML model uses NetworkX centrality, historical mismatch patterns, and filing regularity to predict future compliance risk.
                </div>
                {[
                  { feature: "Mismatch Rate (6mo)", weight: 40, color: "#FF2D55" },
                  { feature: "Filing Regularity", weight: 25, color: "#6366f1" },
                  { feature: "ITC Utilization", weight: 20, color: "#2563EB" },
                  { feature: "Network Centrality", weight: 10, color: "#D97706" },
                  { feature: "Sector Risk", weight: 5, color: "#059669" },
                ].map(f => (
                  <div key={f.feature} style={{ marginBottom: 12 }}>
                    <div style={{ display: "flex", justifyContent: "space-between", fontSize: 11, marginBottom: 4 }}>
                      <span style={{ color: "#999" }}>{f.feature}</span>
                      <span style={{ color: f.color }}>{f.weight}%</span>
                    </div>
                    <div style={{ height: 4, background: "#111", borderRadius: 2 }}>
                      <div style={{ width: `${f.weight}%`, height: "100%", background: f.color, borderRadius: 2 }} />
                    </div>
                  </div>
                ))}
              </div>

              <div style={{ background: "rgba(255,255,255,0.02)", border: "1px solid rgba(255,255,255,0.07)", borderRadius: 16, padding: 24 }}>
                <div style={{ fontSize: 13, fontWeight: 600, color: "#aaa", marginBottom: 16 }}>STATUS DISTRIBUTION</div>
                {[
                  { label: "Compliant", count: VENDORS.filter(v => v.status === "Compliant").length, color: "#34C759" },
                  { label: "At Risk", count: VENDORS.filter(v => v.status === "At Risk").length, color: "#FF9500" },
                  { label: "Non-Compliant", count: VENDORS.filter(v => v.status === "Non-Compliant").length, color: "#FF2D55" },
                ].map(s => (
                  <div key={s.label} style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 14 }}>
                    <div style={{ width: 10, height: 10, borderRadius: 2, background: s.color, flexShrink: 0 }} />
                    <div style={{ flex: 1, fontSize: 12, color: "#999" }}>{s.label}</div>
                    <div style={{ fontSize: 20, fontWeight: 700, color: s.color, fontFamily: "Syne", minWidth: 30 }}>{s.count}</div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}

      </div>

      {/* Footer */}
      <div style={{ borderTop: "1px solid rgba(255,255,255,0.05)", padding: "16px 32px", display: "flex", justifyContent: "space-between", alignItems: "center", fontSize: 11, color: "#444" }}>
        <span>GST Knowledge Graph Reconciliation Engine · Graph DB: NetworkX · Backend: FastAPI · Period: Jan 2024</span>
        <span style={{ color: "#6366f1" }}>1.4 Cr taxpayers · ITC Leakage Protection</span>
      </div>
    </div>
  );
}
