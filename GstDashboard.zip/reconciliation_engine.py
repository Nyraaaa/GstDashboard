"""
GST Knowledge Graph Reconciliation Engine
Uses NetworkX for in-memory graph traversal and multi-hop ITC validation
"""

import networkx as nx
import json
from typing import Dict, List, Optional, Tuple, Any
from collections import defaultdict
from schema import MismatchType, RiskLevel


class GSTKnowledgeGraph:
    """
    In-memory Knowledge Graph using NetworkX DiGraph
    Nodes: Taxpayer, GSTIN, Invoice, IRN, EWayBill, Return, TaxPayment
    Edges: Directed relationships with properties
    """

    def __init__(self):
        self.G = nx.MultiDiGraph()
        self._node_index: Dict[str, Dict] = {}

    def load_from_dict(self, graph_data: Dict):
        """Bulk load graph from dict (from mock_data generator)"""
        seen = set()
        for node in graph_data["nodes"]:
            nid = node["id"]
            if nid not in seen:
                self.G.add_node(nid, **node)
                self._node_index[nid] = node
                seen.add(nid)

        for edge in graph_data["edges"]:
            src, tgt, etype = edge["source"], edge["target"], edge["type"]
            if src in self.G and tgt in self.G:
                self.G.add_edge(src, tgt, rel_type=etype)

        return self

    def node_count(self) -> int:
        return self.G.number_of_nodes()

    def edge_count(self) -> int:
        return self.G.number_of_edges()

    # ─────────────────────────────────────────
    # Graph Traversal Queries
    # ─────────────────────────────────────────

    def get_itc_chain(self, invoice_id: str) -> Dict:
        """
        Multi-hop traversal: Invoice → IRN → EWayBill → GSTR-1 → GSTR-2B → GSTR-3B → Payment
        Returns the full ITC validation chain with status at each hop
        """
        chain = {
            "invoice_id": invoice_id,
            "hops": [],
            "is_valid": True,
            "broken_at": None
        }

        if invoice_id not in self.G:
            chain["is_valid"] = False
            chain["broken_at"] = "Invoice node not found in graph"
            return chain

        inv_data = self.G.nodes[invoice_id]
        chain["invoice_data"] = {k: v for k, v in inv_data.items() if k not in ["id"]}

        # Hop 1: IRN validation
        irn_neighbors = [
            n for n in self.G.successors(invoice_id)
            if self.G.nodes[n].get("type") == "IRN"
        ]
        if irn_neighbors:
            irn_node = self.G.nodes[irn_neighbors[0]]
            chain["hops"].append({
                "hop": 1, "name": "e-Invoice (IRN)",
                "status": "❌ CANCELLED" if irn_node.get("cancelled") else "✅ VALID",
                "node_id": irn_neighbors[0],
                "details": {
                    "ack_no": irn_node.get("ack_no"),
                    "ack_date": irn_node.get("ack_date"),
                    "cancelled": irn_node.get("cancelled"),
                }
            })
            if irn_node.get("cancelled"):
                chain["is_valid"] = False
                chain["broken_at"] = "IRN cancelled — invoice is invalid"
        else:
            chain["hops"].append({
                "hop": 1, "name": "e-Invoice (IRN)",
                "status": "⚠️ MISSING",
                "details": "No IRN found — check if mandatory threshold applies"
            })

        # Hop 2: E-Way Bill
        ewb_neighbors = [
            n for n in self.G.successors(invoice_id)
            if self.G.nodes[n].get("type") == "EWayBill"
        ]
        if ewb_neighbors:
            ewb_node = self.G.nodes[ewb_neighbors[0]]
            chain["hops"].append({
                "hop": 2, "name": "E-Way Bill",
                "status": "✅ FOUND",
                "node_id": ewb_neighbors[0],
                "details": {
                    "ewb_no": ewb_node.get("ewb_no"),
                    "valid_upto": ewb_node.get("valid_upto"),
                    "total_value": ewb_node.get("total_value"),
                }
            })
        else:
            chain["hops"].append({
                "hop": 2, "name": "E-Way Bill",
                "status": "⚠️ MISSING",
                "details": "No E-Way Bill — check if goods value > ₹50,000"
            })

        # Hop 3: GSTR-1 (supplier side)
        supplier_gstin = inv_data.get("supplier_gstin", "")
        gstr1_nodes = [
            n for n in self.G.nodes
            if (self.G.nodes[n].get("type") == "Return" and
                self.G.nodes[n].get("return_type") == "GSTR-1" and
                self.G.nodes[n].get("gstin") == supplier_gstin)
        ]
        if gstr1_nodes:
            r1 = self.G.nodes[gstr1_nodes[0]]
            chain["hops"].append({
                "hop": 3, "name": "GSTR-1 (Supplier)",
                "status": "✅ FILED" if r1.get("status") == "Filed" else "❌ PENDING",
                "details": {
                    "filing_date": r1.get("filing_date"),
                    "status": r1.get("status"),
                    "total_igst": r1.get("total_igst"),
                }
            })
            if r1.get("status") != "Filed":
                chain["is_valid"] = False
                chain["broken_at"] = "Supplier GSTR-1 not filed — ITC auto-blocked"
        else:
            chain["hops"].append({
                "hop": 3, "name": "GSTR-1 (Supplier)",
                "status": "❌ NOT FOUND",
                "details": "Supplier GSTR-1 absent for this period"
            })
            chain["is_valid"] = False
            chain["broken_at"] = "Supplier GSTR-1 not found"

        # Hop 4: GSTR-2B (buyer side)
        buyer_gstin = inv_data.get("buyer_gstin", "")
        gstr2b_nodes = [
            n for n in self.G.nodes
            if (self.G.nodes[n].get("type") == "Return" and
                self.G.nodes[n].get("return_type") == "GSTR-2B" and
                self.G.nodes[n].get("gstin") == buyer_gstin)
        ]
        if gstr2b_nodes:
            r2b = self.G.nodes[gstr2b_nodes[0]]
            chain["hops"].append({
                "hop": 4, "name": "GSTR-2B (Buyer)",
                "status": "✅ REFLECTED",
                "details": {
                    "itc_available": r2b.get("itc_claimed"),
                    "generated_date": r2b.get("filing_date"),
                }
            })
        else:
            chain["hops"].append({
                "hop": 4, "name": "GSTR-2B (Buyer)",
                "status": "❌ NOT REFLECTED",
                "details": "Invoice not appearing in buyer's GSTR-2B"
            })
            chain["is_valid"] = False
            chain["broken_at"] = "Invoice not reflected in GSTR-2B"

        # Hop 5: GSTR-3B + Payment
        gstr3b_nodes = [
            n for n in self.G.nodes
            if (self.G.nodes[n].get("type") == "Return" and
                self.G.nodes[n].get("return_type") == "GSTR-3B" and
                self.G.nodes[n].get("gstin") == buyer_gstin)
        ]
        if gstr3b_nodes:
            r3b = self.G.nodes[gstr3b_nodes[0]]
            chain["hops"].append({
                "hop": 5, "name": "GSTR-3B (ITC Claim)",
                "status": "✅ CLAIMED" if r3b.get("status") == "Filed" else "⏳ PENDING",
                "details": {
                    "itc_claimed": r3b.get("itc_claimed"),
                    "tax_paid": r3b.get("tax_paid"),
                    "status": r3b.get("status"),
                }
            })
        else:
            chain["hops"].append({
                "hop": 5, "name": "GSTR-3B (ITC Claim)",
                "status": "⏳ NOT FILED",
                "details": "GSTR-3B not yet filed"
            })

        return chain

    def find_vendor_network(self, gstin: str, depth: int = 2) -> Dict:
        """
        BFS traversal to find vendor supply network up to N hops
        Useful for identifying circular ITC fraud rings
        """
        if gstin not in self.G:
            return {"gstin": gstin, "network": [], "depth": depth}

        visited = {gstin}
        network = []
        queue = [(gstin, 0)]

        while queue:
            current, level = queue.pop(0)
            if level >= depth:
                continue

            for neighbor in list(self.G.successors(current)) + list(self.G.predecessors(current)):
                if neighbor not in visited:
                    visited.add(neighbor)
                    node_data = self.G.nodes.get(neighbor, {})
                    ntype = node_data.get("type", "")
                    if ntype in ("GSTIN", "Taxpayer"):
                        rel_edges = list(self.G.edges(current, data=True))
                        rel_type = rel_edges[0][2].get("rel_type", "RELATED_TO") if rel_edges else "RELATED_TO"
                        network.append({
                            "gstin": neighbor,
                            "type": ntype,
                            "name": node_data.get("legal_name", node_data.get("gstin", "")),
                            "level": level + 1,
                            "relationship": rel_type,
                        })
                        queue.append((neighbor, level + 1))

        return {"source_gstin": gstin, "network": network, "total_connections": len(network)}

    def detect_circular_itc(self) -> List[Dict]:
        """
        Detect potential circular ITC fraud using simple cycle detection
        A→B→C→A supply cycles with ITC claims at each step
        """
        cycles = []
        try:
            # Find cycles in GSTIN supply graph
            gstin_subgraph = nx.DiGraph()
            for u, v, data in self.G.edges(data=True):
                u_type = self.G.nodes[u].get("type", "")
                v_type = self.G.nodes[v].get("type", "")
                if u_type == "GSTIN" and v_type == "GSTIN":
                    gstin_subgraph.add_edge(u, v)

            for cycle in nx.simple_cycles(gstin_subgraph):
                if len(cycle) >= 3:
                    cycles.append({
                        "cycle": cycle,
                        "length": len(cycle),
                        "risk": "CRITICAL — Circular ITC fraud pattern detected",
                        "recommendation": "Trigger DGGI investigation; freeze ITC claims in cycle"
                    })
        except Exception:
            pass
        return cycles

    def get_graph_stats(self) -> Dict:
        """Graph topology statistics"""
        type_counts = defaultdict(int)
        for n, d in self.G.nodes(data=True):
            type_counts[d.get("type", "Unknown")] += 1

        rel_counts = defaultdict(int)
        for u, v, d in self.G.edges(data=True):
            rel_counts[d.get("rel_type", "Unknown")] += 1

        return {
            "total_nodes": self.G.number_of_nodes(),
            "total_edges": self.G.number_of_edges(),
            "node_types": dict(type_counts),
            "relationship_types": dict(rel_counts),
            "density": round(nx.density(self.G), 6),
            "is_dag": nx.is_directed_acyclic_graph(self.G),
        }


class ReconciliationEngine:
    """
    Multi-source GST Reconciliation Engine
    Compares: PR (Purchase Register) ↔ GSTR-2B ↔ GSTR-1 ↔ e-Invoice
    """

    RISK_THRESHOLDS = {
        RiskLevel.CRITICAL: 500_000,    # > 5 Lakh
        RiskLevel.HIGH: 100_000,        # > 1 Lakh
        RiskLevel.MEDIUM: 25_000,       # > 25K
        RiskLevel.LOW: 0
    }

    def __init__(self, kg: GSTKnowledgeGraph, mismatches: List[Dict]):
        self.kg = kg
        self.mismatches = mismatches

    def classify_risk(self, itc_at_risk: float, mtype: str) -> str:
        """Financial risk classification"""
        if mtype in ["Duplicate Invoice", "Missing in GSTR-2B", "Invalid GSTIN"]:
            if itc_at_risk > 100_000:
                return RiskLevel.CRITICAL.value
        for level, threshold in self.RISK_THRESHOLDS.items():
            if itc_at_risk >= threshold:
                return level.value
        return RiskLevel.LOW.value

    def generate_natural_language_explanation(self, mismatch: Dict) -> str:
        """
        Explainable AI: Natural language audit explanation
        """
        mtype = mismatch.get("mismatch_type", "")
        supplier = mismatch.get("supplier_gstin", "")
        buyer = mismatch.get("buyer_gstin", "")
        variance = mismatch.get("variance", 0)
        itc = mismatch.get("itc_at_risk", 0)
        period = mismatch.get("tax_period", "")

        period_str = f"{period[:2]}/{period[2:]}" if len(period) == 6 else period

        if mtype == MismatchType.AMOUNT_MISMATCH.value:
            return (
                f"For the period {period_str}, supplier {supplier} reported a lower tax amount "
                f"in their GSTR-1 compared to what appears in the buyer's ({buyer}) purchase register. "
                f"The variance of ₹{variance:,.2f} results in ₹{itc:,.2f} of ITC being at risk. "
                f"The supplier must file an amendment return (GSTR-1A) to correct the discrepancy."
            )
        elif mtype == MismatchType.MISSING_IN_2B.value:
            return (
                f"Supplier {supplier} has not filed their GSTR-1 for {period_str}. "
                f"As a result, the invoice does not appear in buyer {buyer}'s GSTR-2B, "
                f"making ₹{itc:,.2f} of Input Tax Credit ineligible under Rule 36(4). "
                f"The buyer should follow up with the supplier and defer this ITC claim."
            )
        elif mtype == MismatchType.IRN_NOT_FOUND.value:
            return (
                f"Invoice from supplier {supplier} to buyer {buyer} has a taxable value "
                f"that exceeds the e-Invoice threshold but no IRN is registered with the IRP. "
                f"This is a strong indicator of a potentially fraudulent or fabricated invoice. "
                f"₹{itc:,.2f} of ITC is at risk and an immediate investigation is recommended."
            )
        elif mtype == MismatchType.DUPLICATE_INVOICE.value:
            return (
                f"The same invoice from supplier {supplier} appears to have been claimed twice "
                f"in buyer {buyer}'s returns for period {period_str}. "
                f"This constitutes a duplicate ITC claim of ₹{itc:,.2f} and must be reversed "
                f"immediately to avoid penalties under Section 74 of the CGST Act."
            )
        elif mtype == MismatchType.EWBILL_MISMATCH.value:
            return (
                f"The E-Way Bill value for the invoice from {supplier} to {buyer} is significantly "
                f"lower than the invoice value, creating a variance of ₹{variance:,.2f}. "
                f"This discrepancy may indicate under-declaration of goods value for tax evasion. "
                f"Physical movement verification and transporter records should be reviewed."
            )
        else:
            return (
                f"A {mtype} was detected in the invoice from {supplier} to {buyer} "
                f"for period {period_str}. ITC at risk: ₹{itc:,.2f}. "
                f"Review the audit trail for detailed reconciliation steps."
            )

    def get_full_reconciliation_report(self) -> Dict:
        """Master reconciliation report with all stats, mismatches, and audit trails"""
        enriched = []
        for m in self.mismatches:
            enriched_m = dict(m)
            enriched_m["nl_explanation"] = self.generate_natural_language_explanation(m)
            enriched_m["reclassified_risk"] = self.classify_risk(
                m.get("itc_at_risk", 0), m.get("mismatch_type", "")
            )
            enriched.append(enriched_m)

        total_itc_at_risk = sum(m.get("itc_at_risk", 0) for m in self.mismatches)
        by_type = defaultdict(list)
        by_risk = defaultdict(list)
        for m in enriched:
            by_type[m["mismatch_type"]].append(m)
            by_risk[m["risk_level"]].append(m)

        return {
            "total_mismatches": len(enriched),
            "total_itc_at_risk": round(total_itc_at_risk, 2),
            "by_type": {k: len(v) for k, v in by_type.items()},
            "by_risk": {k: len(v) for k, v in by_risk.items()},
            "mismatches": enriched,
            "graph_stats": self.kg.get_graph_stats(),
        }


def load_and_run():
    """Load data, build graph, run reconciliation"""
    with open("../data/graph_data.json") as f:
        graph_data = json.load(f)

    kg = GSTKnowledgeGraph()
    kg.load_from_dict(graph_data)

    engine = ReconciliationEngine(kg, graph_data["mismatches"])
    report = engine.get_full_reconciliation_report()
    stats = kg.get_graph_stats()

    print(f"✅ Graph loaded: {stats['total_nodes']} nodes, {stats['total_edges']} edges")
    print(f"📊 Mismatches: {report['total_mismatches']}")
    print(f"💰 ITC at risk: ₹{report['total_itc_at_risk']:,.2f}")
    print(f"📈 By risk level: {report['by_risk']}")

    return kg, engine, report


if __name__ == "__main__":
    load_and_run()
