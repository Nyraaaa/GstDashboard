"""
Mock Data Generator for GST Knowledge Graph
Generates realistic GSTR-1, GSTR-2B, Purchase Register, e-Invoice & e-Way Bill data
"""

import random
import hashlib
import json
from datetime import datetime, timedelta
from typing import Dict, List, Tuple
from schema import (
    TaxpayerNode, GSTINNode, InvoiceNode, IRNNode,
    ReturnNode, EWayBillNode, TaxPaymentNode,
    ReturnType, ComplianceStatus, MismatchType, RiskLevel, MismatchRecord
)

random.seed(42)

# ─────────────────────────────────────────────
# Master Data
# ─────────────────────────────────────────────

STATES = {
    "27": "Maharashtra", "29": "Karnataka", "07": "Delhi",
    "33": "Tamil Nadu", "09": "Uttar Pradesh", "24": "Gujarat",
    "36": "Telangana", "19": "West Bengal", "32": "Kerala"
}

SECTORS = ["Manufacturing", "Trading", "Services", "Construction",
           "Pharmaceuticals", "IT", "Textiles", "FMCG", "Auto Components", "Chemical"]

HSN_CODES = {
    "8471": "Computers", "6101": "Garments", "2710": "Petroleum Products",
    "8517": "Mobile Phones", "3004": "Medicines", "7308": "Steel Structures",
    "8703": "Motor Cars", "5209": "Cotton Fabric", "2917": "Chemicals",
    "0901": "Coffee"
}

COMPANY_PREFIXES = [
    "Apex", "Bharat", "Chandra", "Delta", "Eagle", "Falcon",
    "Global", "Horizon", "Indus", "Jaguar", "Kiran", "Lotus"
]

COMPANY_SUFFIXES = [
    "Industries Ltd", "Trading Co", "Enterprises Pvt Ltd",
    "Manufacturing Ltd", "Solutions Pvt Ltd", "Traders"
]


def make_gstin(state_code: str, pan: str) -> str:
    """Generate a valid-format GSTIN"""
    entity_code = f"{random.randint(1,9)}"
    check = str(random.randint(0, 9))
    return f"{state_code}{pan}{entity_code}Z{check}"


def make_irn(invoice_no: str, gstin: str, date: str) -> str:
    raw = f"{gstin}{invoice_no}{date}"
    return hashlib.sha256(raw.encode()).hexdigest()[:64]


def make_pan() -> str:
    letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    return (
        ''.join(random.choices(letters, k=5)) +
        ''.join(random.choices("0123456789", k=4)) +
        random.choice(letters)
    )


def random_date(start: datetime, end: datetime) -> str:
    delta = end - start
    days = random.randint(0, delta.days)
    return (start + timedelta(days=days)).strftime("%Y-%m-%d")


def tax_from_value(value: float, place: str, supplier_state: str) -> Tuple[float, float, float, float]:
    """Returns (igst, cgst, sgst, cess)"""
    rate = random.choice([0.05, 0.12, 0.18, 0.28])
    total_tax = round(value * rate, 2)
    cess = round(value * random.choice([0, 0.01, 0.04]), 2) if rate == 0.28 else 0

    if place != supplier_state:
        return total_tax, 0, 0, cess
    else:
        half = round(total_tax / 2, 2)
        return 0, half, half, cess


# ─────────────────────────────────────────────
# Main Generator
# ─────────────────────────────────────────────

class GSTDataGenerator:

    def __init__(self, num_taxpayers: int = 20, tax_period: str = "012024"):
        self.num_taxpayers = num_taxpayers
        self.tax_period = tax_period
        self.period_start = datetime(2024, 1, 1)
        self.period_end = datetime(2024, 1, 31)

        self.taxpayers: List[TaxpayerNode] = []
        self.gstins: List[GSTINNode] = []
        self.invoices: List[InvoiceNode] = []
        self.irns: List[IRNNode] = []
        self.returns: List[ReturnNode] = []
        self.ewbs: List[EWayBillNode] = []
        self.payments: List[TaxPaymentNode] = []
        self.mismatches: List[MismatchRecord] = []
        self.gstin_map: Dict[str, GSTINNode] = {}

        self._generate()

    def _generate(self):
        self._gen_taxpayers()
        self._gen_invoices()
        self._gen_irns()
        self._gen_ewbs()
        self._gen_returns()
        self._gen_payments()
        self._inject_mismatches()

    def _gen_taxpayers(self):
        for i in range(self.num_taxpayers):
            pan = make_pan()
            state_code = random.choice(list(STATES.keys()))
            sector = random.choice(SECTORS)
            name = f"{random.choice(COMPANY_PREFIXES)} {random.choice(COMPANY_SUFFIXES)}"
            trade = f"{random.choice(COMPANY_PREFIXES)} {sector}"

            # Assign compliance profile
            compliance_score = round(random.gauss(78, 18), 1)
            compliance_score = max(10, min(100, compliance_score))
            if compliance_score >= 85:
                status = ComplianceStatus.COMPLIANT
            elif compliance_score >= 60:
                status = ComplianceStatus.AT_RISK
            elif compliance_score >= 30:
                status = ComplianceStatus.NON_COMPLIANT
            else:
                status = ComplianceStatus.SUSPENDED

            tp = TaxpayerNode(
                pan=pan, legal_name=name, trade_name=trade,
                state_code=state_code, sector=sector,
                registration_date=random_date(datetime(2017, 7, 1), datetime(2022, 1, 1)),
                compliance_score=compliance_score, status=status
            )
            self.taxpayers.append(tp)

            # 1-2 GSTINs per taxpayer
            for _ in range(random.randint(1, 2)):
                sc = random.choice(list(STATES.keys()))
                gstin = make_gstin(sc, pan)
                reg_type = random.choices(
                    ["Regular", "Composition", "SEZ"],
                    weights=[80, 15, 5]
                )[0]
                g = GSTINNode(
                    gstin=gstin, taxpayer_pan=pan, state_code=sc,
                    registration_type=reg_type,
                    effective_date=random_date(datetime(2017, 7, 1), datetime(2022, 1, 1)),
                    aggregate_turnover=round(random.uniform(50e5, 500e7), 2)
                )
                self.gstins.append(g)
                self.gstin_map[gstin] = g

        # Ensure at least some GSTINs
        if not self.gstins:
            return

    def _gen_invoices(self):
        gstins = [g.gstin for g in self.gstins]
        hsn_items = list(HSN_CODES.keys())
        inv_counter = 1000

        for _ in range(min(len(gstins) * 8, 200)):
            supplier_gstin = random.choice(gstins)
            buyer_gstin = random.choice([g for g in gstins if g != supplier_gstin] or gstins)

            inv_no = f"INV/{self.tax_period}/{inv_counter}"
            inv_counter += 1
            inv_date = random_date(self.period_start, self.period_end)

            value = round(random.uniform(10000, 5000000), 2)
            supplier_state = supplier_gstin[:2]
            buyer_state = buyer_gstin[:2]
            pos = buyer_state  # place of supply

            igst, cgst, sgst, cess = tax_from_value(value, pos, supplier_state)
            total_tax = round(igst + cgst + sgst + cess, 2)
            hsn = random.choice(hsn_items)

            inv = InvoiceNode(
                invoice_no=inv_no,
                supplier_gstin=supplier_gstin,
                buyer_gstin=buyer_gstin,
                invoice_date=inv_date,
                invoice_type="B2B",
                taxable_value=value,
                igst=igst, cgst=cgst, sgst=sgst, cess=cess,
                total_tax=total_tax,
                hsn_code=hsn,
                place_of_supply=pos,
                reverse_charge=random.random() < 0.05,
            )
            self.invoices.append(inv)

    def _gen_irns(self):
        # ~85% of invoices have IRN (mandatory for turnover > 5Cr)
        for inv in self.invoices:
            if random.random() < 0.85:
                irn = make_irn(inv.invoice_no, inv.supplier_gstin, inv.invoice_date)
                ack_no = str(random.randint(10**17, 10**18))
                irn_node = IRNNode(
                    irn=irn,
                    invoice_no=inv.invoice_no,
                    supplier_gstin=inv.supplier_gstin,
                    irp_generated_at=inv.invoice_date + "T09:00:00",
                    ack_no=ack_no,
                    ack_date=inv.invoice_date,
                    signed_qr_code=hashlib.md5(irn.encode()).hexdigest(),
                    cancelled=random.random() < 0.03
                )
                self.irns.append(irn_node)
                inv.irn = irn

    def _gen_ewbs(self):
        # ~70% of B2B goods invoices have e-Way Bill
        ewb_counter = 400000000
        for inv in self.invoices:
            if random.random() < 0.70 and inv.taxable_value > 50000:
                ewb_no = str(ewb_counter)
                ewb_counter += 1
                gen_date = inv.invoice_date
                valid_days = max(1, int(random.randint(50, 1000) / 100))
                valid_upto_dt = datetime.strptime(gen_date, "%Y-%m-%d") + timedelta(days=valid_days)

                ewb = EWayBillNode(
                    ewb_no=ewb_no,
                    invoice_no=inv.invoice_no,
                    supplier_gstin=inv.supplier_gstin,
                    recipient_gstin=inv.buyer_gstin,
                    generated_date=gen_date,
                    valid_upto=valid_upto_dt.strftime("%Y-%m-%d"),
                    vehicle_no=f"MH{random.randint(10,99)}AB{random.randint(1000,9999)}",
                    distance_km=random.randint(10, 2000),
                    transporter_id=f"TRANS{random.randint(10000, 99999)}",
                    supply_type="Outward",
                    document_type="Invoice",
                    total_value=inv.total_amount
                )
                self.ewbs.append(ewb)
                inv.ewb_no = ewb_no

    def _gen_returns(self):
        filing_date = "2024-02-11"
        for g in self.gstins:
            invoices_by_supplier = [i for i in self.invoices if i.supplier_gstin == g.gstin]
            invoices_by_buyer = [i for i in self.invoices if i.buyer_gstin == g.gstin]

            filed = random.random() < 0.88

            # GSTR-1
            r1_id = f"GSTR1_{g.gstin}_{self.tax_period}"
            r1 = ReturnNode(
                return_id=r1_id, return_type=ReturnType.GSTR1,
                gstin=g.gstin, tax_period=self.tax_period,
                filing_date=filing_date if filed else None,
                status="Filed" if filed else "Pending",
                total_taxable_value=sum(i.taxable_value for i in invoices_by_supplier),
                total_igst=sum(i.igst for i in invoices_by_supplier),
                total_cgst=sum(i.cgst for i in invoices_by_supplier),
                total_sgst=sum(i.sgst for i in invoices_by_supplier),
            )
            self.returns.append(r1)

            # GSTR-2B (auto-populated from supplier's GSTR-1)
            r2b_id = f"GSTR2B_{g.gstin}_{self.tax_period}"
            r2b = ReturnNode(
                return_id=r2b_id, return_type=ReturnType.GSTR2B,
                gstin=g.gstin, tax_period=self.tax_period,
                filing_date="2024-02-14",  # auto-generated by GST system
                status="Generated",
                total_taxable_value=sum(i.taxable_value for i in invoices_by_buyer),
                itc_claimed=sum(i.total_tax for i in invoices_by_buyer),
            )
            self.returns.append(r2b)

            # GSTR-3B
            r3b_id = f"GSTR3B_{g.gstin}_{self.tax_period}"
            r3b_filed = random.random() < 0.90
            itc = sum(i.total_tax for i in invoices_by_buyer) * random.uniform(0.85, 1.0)
            tax_paid = max(0, sum(i.total_tax for i in invoices_by_supplier) - itc)
            r3b = ReturnNode(
                return_id=r3b_id, return_type=ReturnType.GSTR3B,
                gstin=g.gstin, tax_period=self.tax_period,
                filing_date="2024-02-20" if r3b_filed else None,
                status="Filed" if r3b_filed else "Pending",
                itc_claimed=round(itc, 2),
                tax_paid=round(tax_paid, 2),
            )
            self.returns.append(r3b)

    def _gen_payments(self):
        for r in self.returns:
            if r.return_type == ReturnType.GSTR3B and r.status == "Filed" and r.tax_paid > 0:
                payment = TaxPaymentNode(
                    payment_id=f"PMT_{r.gstin}_{self.tax_period}",
                    gstin=r.gstin,
                    tax_period=self.tax_period,
                    payment_date=r.filing_date or "2024-02-20",
                    igst_paid=round(r.tax_paid * 0.6, 2),
                    cgst_paid=round(r.tax_paid * 0.2, 2),
                    sgst_paid=round(r.tax_paid * 0.2, 2),
                    cess_paid=0,
                    challan_no=f"CPIN{random.randint(10**13, 10**14)}",
                    bank_ref=f"HDFC{random.randint(10**9, 10**10)}"
                )
                self.payments.append(payment)

    def _inject_mismatches(self):
        """Inject realistic mismatches for reconciliation testing"""
        mismatch_counter = 1

        for inv in self.invoices[:50]:  # Inject mismatches in first 50 invoices
            r = random.random()
            mtype = None
            risk = None
            variance = 0
            root_cause = ""
            recommendation = ""

            if r < 0.15:
                # Amount mismatch
                mtype = MismatchType.AMOUNT_MISMATCH
                actual = round(inv.total_tax * random.uniform(0.7, 0.95), 2)
                variance = round(inv.total_tax - actual, 2)
                risk = RiskLevel.HIGH if variance > 50000 else RiskLevel.MEDIUM
                root_cause = "Supplier filed incorrect tax amount in GSTR-1 vs e-Invoice amount"
                recommendation = "Issue SCN (Show Cause Notice) to supplier; reverse excess ITC claimed"
                itc_risk = variance

            elif r < 0.28:
                # Missing in 2B
                mtype = MismatchType.MISSING_IN_2B
                actual = 0
                variance = inv.total_tax
                risk = RiskLevel.CRITICAL
                root_cause = "Supplier did not file GSTR-1 for this period; invoice not reflected in GSTR-2B"
                recommendation = "Contact supplier to file GSTR-1; hold ITC claim until reconciliation"
                itc_risk = inv.total_tax

            elif r < 0.38:
                # IRN not found
                mtype = MismatchType.IRN_NOT_FOUND
                actual = 0
                variance = inv.total_tax
                risk = RiskLevel.HIGH
                root_cause = "Invoice value exceeds ₹5 Cr threshold but no IRN generated — possible fake invoice"
                recommendation = "Verify physical delivery; request IRN from supplier; potential fraud alert"
                itc_risk = inv.total_tax * 1.1  # Penalty included

            elif r < 0.44:
                # E-Way Bill mismatch
                mtype = MismatchType.EWBILL_MISMATCH
                actual = inv.taxable_value * 0.8
                variance = inv.taxable_value - actual
                risk = RiskLevel.MEDIUM
                root_cause = "E-Way Bill value significantly lower than invoice value — under-declaration suspicion"
                recommendation = "Cross-check with transporter records; verify vehicle movement logs"
                itc_risk = variance * 0.18  # 18% GST on variance

            elif r < 0.48:
                # Duplicate invoice
                mtype = MismatchType.DUPLICATE_INVOICE
                actual = inv.total_tax
                variance = inv.total_tax  # Duplicate claim
                risk = RiskLevel.CRITICAL
                root_cause = "Same invoice number reported twice with different dates — duplicate ITC claim detected"
                recommendation = "Immediate reversal of duplicate ITC; possible penalty u/s 74"
                itc_risk = inv.total_tax

            else:
                continue

            trail = self._generate_audit_trail(inv, mtype)
            var_pct = round((variance / inv.total_tax * 100) if inv.total_tax else 0, 2)

            m = MismatchRecord(
                mismatch_id=f"MM_{mismatch_counter:04d}",
                invoice_id=f"INV_{inv.invoice_no}_{inv.supplier_gstin[:5]}",
                mismatch_type=mtype,
                risk_level=risk,
                supplier_gstin=inv.supplier_gstin,
                buyer_gstin=inv.buyer_gstin,
                tax_period=self.tax_period,
                expected_amount=round(inv.total_tax, 2),
                actual_amount=round(actual, 2) if mtype != MismatchType.MISSING_IN_2B else 0,
                variance=round(variance, 2),
                variance_pct=var_pct,
                root_cause=root_cause,
                audit_trail=trail,
                recommendation=recommendation,
                itc_at_risk=round(itc_risk, 2)
            )
            self.mismatches.append(m)
            mismatch_counter += 1

    def _generate_audit_trail(self, inv: InvoiceNode, mtype: MismatchType) -> List[str]:
        trail = [
            f"[STEP 1] Invoice {inv.invoice_no} identified in Purchase Register (PR) for GSTIN {inv.buyer_gstin}",
            f"[STEP 2] Cross-referenced with GSTR-2B for period {self.tax_period}",
        ]
        if mtype == MismatchType.MISSING_IN_2B:
            trail.append(f"[STEP 3] Invoice NOT found in GSTR-2B — supplier GSTR-1 check initiated")
            trail.append(f"[STEP 4] Supplier GSTIN {inv.supplier_gstin} GSTR-1 status: PENDING/NOT FILED")
            trail.append(f"[STEP 5] ITC of ₹{inv.total_tax:,.2f} flagged as INELIGIBLE until supplier compliance")
        elif mtype == MismatchType.AMOUNT_MISMATCH:
            trail.append(f"[STEP 3] Amount in GSTR-2B differs from Purchase Register by > ₹500")
            trail.append(f"[STEP 4] e-Invoice (IRN) amount cross-checked: matches PR amount")
            trail.append(f"[STEP 5] GSTR-1 filed amount lower than e-Invoice — supplier amendment required")
        elif mtype == MismatchType.IRN_NOT_FOUND:
            trail.append(f"[STEP 3] Invoice value ₹{inv.taxable_value:,.2f} > ₹5Cr threshold — IRN mandatory")
            trail.append(f"[STEP 4] IRP (Invoice Registration Portal) queried — IRN not found")
            trail.append(f"[STEP 5] Risk Classification: HIGH — Possible fake/fraudulent invoice")
        elif mtype == MismatchType.DUPLICATE_INVOICE:
            trail.append(f"[STEP 3] Identical invoice_no detected in GSTR-2B for two separate periods")
            trail.append(f"[STEP 4] Hash comparison of invoice data reveals same supplier+amount+date")
            trail.append(f"[STEP 5] DUPLICATE ITC claim of ₹{inv.total_tax:,.2f} flagged for reversal")
        elif mtype == MismatchType.EWBILL_MISMATCH:
            trail.append(f"[STEP 3] E-Way Bill retrieved for invoice — value mismatch detected")
            trail.append(f"[STEP 4] EWB value < Invoice value by > 20% — under-declaration suspected")
            trail.append(f"[STEP 5] Physical movement verification recommended; potential section 129 penalty")
        trail.append(f"[STEP {len(trail)+1-1}] Mismatch classified and risk score computed via Graph traversal")
        return trail

    def to_graph_dict(self) -> Dict:
        """Export full graph as node/edge dictionary"""
        nodes = []
        edges = []

        for tp in self.taxpayers:
            nodes.append(tp.to_dict())
        for g in self.gstins:
            nodes.append(g.to_dict())
            nodes.append({"id": f"TP_{g.taxpayer_pan}", "type": "Taxpayer"})  # ensure ref exists
            edges.append({
                "source": f"TP_{g.taxpayer_pan}",
                "target": g.gstin,
                "type": "HAS_GSTIN"
            })
        for inv in self.invoices:
            nodes.append(inv.to_dict())
            edges.append({"source": inv.to_dict()["id"], "target": inv.supplier_gstin, "type": "ISSUED_BY"})
            edges.append({"source": inv.to_dict()["id"], "target": inv.buyer_gstin, "type": "ISSUED_TO"})
        for irn in self.irns:
            nodes.append(irn.to_dict())
            edges.append({"source": f"INV_{irn.invoice_no}_{irn.supplier_gstin[:5]}", "target": irn.irn, "type": "HAS_IRN"})
        for ewb in self.ewbs:
            nodes.append(ewb.to_dict())
            edges.append({
                "source": f"INV_{ewb.invoice_no}_{ewb.supplier_gstin[:5]}",
                "target": f"EWB_{ewb.ewb_no}",
                "type": "HAS_EWBILL"
            })
        for ret in self.returns:
            nodes.append(ret.to_dict())
        for pmt in self.payments:
            nodes.append(pmt.to_dict())

        return {
            "nodes": nodes,
            "edges": edges,
            "mismatches": [m.to_dict() for m in self.mismatches]
        }

    def get_vendor_risk_scores(self) -> List[Dict]:
        scores = []
        for tp in self.taxpayers:
            gstin_list = [g.gstin for g in self.gstins if g.taxpayer_pan == tp.pan]
            inv_as_supplier = [i for i in self.invoices if i.supplier_gstin in gstin_list]
            mm_as_supplier = [m for m in self.mismatches if m.supplier_gstin in gstin_list]

            total_supplied = sum(i.total_tax for i in inv_as_supplier)
            total_at_risk = sum(m.itc_at_risk for m in mm_as_supplier)
            mismatch_rate = len(mm_as_supplier) / max(len(inv_as_supplier), 1) * 100

            # Composite risk score
            risk_score = min(100, (
                (mismatch_rate * 0.4) +
                ((100 - tp.compliance_score) * 0.4) +
                (min(total_at_risk / max(total_supplied, 1) * 100, 100) * 0.2)
            ))

            scores.append({
                "gstin": gstin_list[0] if gstin_list else "N/A",
                "legal_name": tp.legal_name,
                "sector": tp.sector,
                "compliance_score": tp.compliance_score,
                "risk_score": round(risk_score, 1),
                "total_supplied_tax": round(total_supplied, 2),
                "itc_at_risk": round(total_at_risk, 2),
                "mismatch_count": len(mm_as_supplier),
                "invoice_count": len(inv_as_supplier),
                "mismatch_rate": round(mismatch_rate, 1),
                "status": tp.status.value,
                "state": STATES.get(tp.state_code, tp.state_code),
            })

        return sorted(scores, key=lambda x: x["risk_score"], reverse=True)

    def get_summary_stats(self) -> Dict:
        total_itc_pool = sum(i.total_tax for i in self.invoices)
        total_at_risk = sum(m.itc_at_risk for m in self.mismatches)
        critical = sum(1 for m in self.mismatches if m.risk_level == RiskLevel.CRITICAL)
        high = sum(1 for m in self.mismatches if m.risk_level == RiskLevel.HIGH)

        return {
            "total_taxpayers": len(self.taxpayers),
            "total_gstins": len(self.gstins),
            "total_invoices": len(self.invoices),
            "total_irns": len(self.irns),
            "total_ewbs": len(self.ewbs),
            "total_returns": len(self.returns),
            "total_payments": len(self.payments),
            "total_mismatches": len(self.mismatches),
            "critical_mismatches": critical,
            "high_mismatches": high,
            "total_itc_pool": round(total_itc_pool, 2),
            "total_itc_at_risk": round(total_at_risk, 2),
            "itc_leakage_pct": round(total_at_risk / max(total_itc_pool, 1) * 100, 2),
            "reconciliation_rate": round((len(self.invoices) - len(self.mismatches)) / max(len(self.invoices), 1) * 100, 1),
        }


# Generate and export
if __name__ == "__main__":
    gen = GSTDataGenerator(num_taxpayers=20)
    graph = gen.to_graph_dict()
    stats = gen.get_summary_stats()
    vendors = gen.get_vendor_risk_scores()

    with open("../data/graph_data.json", "w") as f:
        json.dump(graph, f, indent=2)

    with open("../data/summary_stats.json", "w") as f:
        json.dump(stats, f, indent=2)

    with open("../data/vendor_risk.json", "w") as f:
        json.dump(vendors, f, indent=2)

    print("✅ Generated:")
    print(f"  Nodes: {len(graph['nodes'])}")
    print(f"  Edges: {len(graph['edges'])}")
    print(f"  Mismatches: {len(graph['mismatches'])}")
    print(f"  Summary: {stats}")
