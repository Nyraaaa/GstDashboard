# GST Reconciliation Engine — Knowledge Graph Architecture

## Overview

A production-ready, Knowledge Graph-based GST reconciliation system that models India's GST ecosystem as an interconnected graph, enabling multi-hop traversal for ITC (Input Tax Credit) validation, mismatch classification by financial risk, and explainable audit trail generation.

---

## Architecture

```
┌─────────────────────────────────────────────────────────────┐
│                     KNOWLEDGE GRAPH LAYER                    │
│   Neo4j / Amazon Neptune / ArangoDB / NetworkX (dev)        │
├──────────────┬──────────────┬───────────────┬───────────────┤
│   Taxpayer   │    GSTIN     │   Invoice     │     IRN       │
│     Node     │    Node      │    Node       │    Node       │
├──────────────┴──────────────┴───────────────┴───────────────┤
│   EWayBill   │   Return     │  TaxPayment   │   (edges)     │
│    Node      │    Node      │    Node       │  15 rel types │
└──────────────┴──────────────┴───────────────┴───────────────┘
                             ↕
┌─────────────────────────────────────────────────────────────┐
│              RECONCILIATION ENGINE (Python)                  │
│  • Multi-hop graph traversal (PR ↔ GSTR-1 ↔ GSTR-2B)       │
│  • Mismatch classification (5 types, 4 risk levels)         │
│  • ITC chain validation (5-hop path)                        │
│  • Circular ITC fraud detection (cycle detection)           │
│  • NL audit trail generation                                │
└─────────────────────────────────────────────────────────────┘
                             ↕
┌─────────────────────────────────────────────────────────────┐
│              FastAPI REST Backend                            │
│  GET /api/stats          · Summary statistics               │
│  GET /api/mismatches     · Filtered mismatch list           │
│  GET /api/vendors        · Vendor risk scores               │
│  GET /api/graph/nodes    · Graph node browser               │
│  GET /api/itc-chain/{id} · Multi-hop ITC chain              │
│  GET /api/audit/{id}     · Explainable audit trail          │
│  GET /api/circular-itc   · Fraud ring detection             │
└─────────────────────────────────────────────────────────────┘
                             ↕
┌─────────────────────────────────────────────────────────────┐
│           React Dashboard (5 Tabs)                          │
│  📊 Overview  ·  ⚠ Mismatches  ·  ◎ Graph                  │
│  ⛓ ITC Chain  ·  ⬡ Vendor Risk                             │
└─────────────────────────────────────────────────────────────┘
```

---

## Knowledge Graph Schema

### Nodes (7 types)

| Node | Key Properties | Purpose |
|------|---------------|---------|
| **Taxpayer** | PAN, legal_name, sector, compliance_score | Master entity for business |
| **GSTIN** | gstin (15-char), state_code, reg_type, turnover | State-wise tax registration |
| **Invoice** | invoice_no, taxable_value, IGST/CGST/SGST, HSN | Central transaction node |
| **IRN** | irn (64-char hash), ack_no, ack_date, cancelled | e-Invoice registration proof |
| **EWayBill** | ewb_no, valid_upto, vehicle_no, distance_km | Goods movement validation |
| **Return** | return_id, return_type, tax_period, itc_claimed | GSTR-1/2B/3B filings |
| **TaxPayment** | payment_id, challan_no, IGST/CGST/SGST paid | Electronic cash ledger |

### Edges (Relationships)

```cypher
(Taxpayer)-[:HAS_GSTIN]->(GSTIN)
(Invoice)-[:ISSUED_BY]->(GSTIN)         -- supplier
(Invoice)-[:ISSUED_TO]->(GSTIN)         -- buyer  
(Invoice)-[:HAS_IRN]->(IRN)             -- e-Invoice link
(Invoice)-[:HAS_EWBILL]->(EWayBill)    -- movement link
(Invoice)-[:REPORTED_IN]->(Return)      -- GSTR-1 filing
(Invoice)-[:CLAIMED_IN]->(Return)       -- GSTR-2B/3B claim
(Return)-[:PAID_VIA]->(TaxPayment)     -- tax settlement
(GSTIN)-[:SUPPLYING_TO]->(GSTIN)       -- trade network
```

---

## Reconciliation Engine

### Multi-Source Comparison Matrix

```
Purchase Register (PR) 
       ↕ HOP 1
GSTR-2B (auto-populated)
       ↕ HOP 2
GSTR-1 (supplier filing)
       ↕ HOP 3
e-Invoice / IRN
       ↕ HOP 4
E-Way Bill
       ↕ HOP 5
GSTR-3B + Payment
```

### Mismatch Types & Risk Classification

| Mismatch Type | Description | Default Risk |
|---------------|-------------|-------------|
| **Missing in GSTR-2B** | Supplier didn't file GSTR-1 | CRITICAL |
| **Duplicate Invoice** | Same invoice claimed twice | CRITICAL |
| **IRN Not Found** | No e-Invoice for mandatory cases | HIGH |
| **Amount Mismatch** | PR ≠ GSTR-2B amount | HIGH/MEDIUM |
| **E-Way Bill Mismatch** | EWB value < Invoice value | MEDIUM |

### Risk Thresholds

- **CRITICAL**: ITC at risk > ₹5 Lakh OR duplicate/fraud pattern
- **HIGH**: ITC at risk > ₹1 Lakh
- **MEDIUM**: ITC at risk > ₹25K
- **LOW**: < ₹25K

---

## Vendor Compliance Risk Model

Composite risk score (0-100):

```python
risk_score = (
    mismatch_rate_6months * 0.40 +    # Historical mismatch %
    (100 - compliance_score) * 0.40 +  # Filing regularity
    itc_leakage_ratio * 0.20           # ITC at risk / total supplied
)
```

Graph features used:
- **Degree centrality**: How many buyers depend on this supplier
- **Filing regularity**: GSTR-1 on-time filing history
- **Network risk propagation**: High-risk suppliers in vendor network
- **Sector risk coefficient**: Industry-specific compliance benchmarks

---

## API Reference

```bash
# Run locally
cd backend
pip install fastapi uvicorn networkx
python api.py
# → http://localhost:8000

# Key endpoints
GET /api/stats                           # Dashboard KPIs
GET /api/mismatches?risk_level=CRITICAL  # Filter by risk
GET /api/vendors                         # Vendor risk ranking
GET /api/itc-chain/{invoice_id}          # 5-hop ITC validation
GET /api/audit/{mismatch_id}             # NL audit explanation
GET /api/circular-itc                    # Fraud ring detection
GET /api/vendor/{gstin}/network?depth=2  # Supply network BFS
```

---

## Production Graph Database Options

### Neo4j (Recommended for Production)

```cypher
// Create indexes
CREATE INDEX FOR (i:Invoice) ON (i.invoice_no)
CREATE INDEX FOR (g:GSTIN) ON (g.gstin)
CREATE INDEX FOR (r:Return) ON (r.tax_period, r.gstin)

// Sample reconciliation query
MATCH (buyer:GSTIN {gstin: $buyer_gstin})
MATCH (inv:Invoice)-[:ISSUED_TO]->(buyer)
OPTIONAL MATCH (inv)-[:HAS_IRN]->(irn:IRN)
OPTIONAL MATCH (inv)-[:HAS_EWBILL]->(ewb:EWayBill)
OPTIONAL MATCH (inv)-[:ISSUED_BY]->(supplier:GSTIN)
OPTIONAL MATCH (supplier)<-[:ISSUED_BY]-(r:Return {return_type: 'GSTR-1', tax_period: $period})
RETURN inv, irn, ewb, r
```

### Amazon Neptune (AWS Deployment)

```python
# Gremlin traversal for ITC chain
g.V().has('Invoice', 'invoice_no', invoice_no)
 .out('HAS_IRN').as_('irn')
 .select('invoice').out('ISSUED_BY').in_('HAS_GSTIN')
 .out('FILED').has('Return', 'return_type', 'GSTR-1')
 .select('irn', 'gstr1').path()
```

### ArangoDB (Multi-Model)

```aql
// AQL for circular ITC detection
FOR path IN 2..6 OUTBOUND 'gstin/27JHACF2345P1Z6'
  GRAPH 'gst_supply_network'
  FILTER path.vertices[-1]._id == 'gstin/27JHACF2345P1Z6'
  RETURN path
```

---

## Data Flow

```
IRP (e-Invoice Portal)   →  IRN Nodes
NIC (E-Way Bill Portal)  →  EWayBill Nodes  
GSTN (GSTR-1/2B/3B)     →  Return Nodes
Purchase Register (ERP)  →  Invoice Nodes (buyer side)
GST Portal (Challan)     →  TaxPayment Nodes
```

---

## Files

| File | Purpose |
|------|---------|
| `schema.py` | All dataclasses, enums, node/edge definitions |
| `mock_data.py` | Realistic GST data generator (20 taxpayers, 200 invoices) |
| `reconciliation_engine.py` | NetworkX KG + reconciliation logic |
| `api.py` | FastAPI REST endpoints |
| `GSTReconciliationDashboard.jsx` | React dashboard (self-contained) |
| `graph_data.json` | Pre-generated graph data (658 nodes, 742 edges) |

---

## Key Metrics (Mock Dataset)

- **Taxpayers**: 20 · **GSTINs**: 29 · **Invoices**: 200
- **IRNs**: 168 (84% coverage) · **E-Way Bills**: 145
- **Total ITC Pool**: ₹9.06 Cr
- **ITC at Risk**: ₹86.27L (9.53% leakage)
- **Reconciliation Rate**: 85.5%
- **Critical Mismatches**: 9 · **High**: 13 · **Medium**: 7
