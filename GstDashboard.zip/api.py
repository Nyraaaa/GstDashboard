"""
GST Reconciliation API — FastAPI Backend
Endpoints: /stats, /mismatches, /vendors, /graph, /itc-chain/{invoice_id}, /audit/{mismatch_id}
"""

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import json
import sys
import os

sys.path.insert(0, os.path.dirname(__file__))
from schema import MismatchType, RiskLevel
from mock_data import GSTDataGenerator
from reconciliation_engine import GSTKnowledgeGraph, ReconciliationEngine

app = FastAPI(
    title="GST Reconciliation API",
    description="Knowledge Graph-powered GST ITC Reconciliation Engine",
    version="1.0.0"
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ─────────────────────────────────────────────
# Startup: Generate data and build graph
# ─────────────────────────────────────────────

gen = GSTDataGenerator(num_taxpayers=20)
graph_data = gen.to_graph_dict()

kg = GSTKnowledgeGraph()
kg.load_from_dict(graph_data)

engine = ReconciliationEngine(kg, graph_data["mismatches"])
report = engine.get_full_reconciliation_report()


@app.get("/")
def root():
    return {"message": "GST Knowledge Graph Reconciliation Engine v1.0", "status": "running"}


@app.get("/api/stats")
def get_summary_stats():
    """High-level dashboard summary statistics"""
    base = gen.get_summary_stats()
    base["graph_stats"] = kg.get_graph_stats()
    return base


@app.get("/api/mismatches")
def get_mismatches(
    risk_level: str = None,
    mismatch_type: str = None,
    limit: int = 100
):
    """Get all mismatches, optionally filtered by risk level or type"""
    results = report["mismatches"]

    if risk_level:
        results = [m for m in results if m["risk_level"] == risk_level]
    if mismatch_type:
        results = [m for m in results if m["mismatch_type"] == mismatch_type]

    return {
        "total": len(results),
        "mismatches": results[:limit],
        "by_risk": report["by_risk"],
        "by_type": report["by_type"],
        "total_itc_at_risk": report["total_itc_at_risk"]
    }


@app.get("/api/vendors")
def get_vendor_risk():
    """Vendor compliance risk scores ranked by risk"""
    vendors = gen.get_vendor_risk_scores()
    return {
        "total": len(vendors),
        "vendors": vendors,
        "avg_compliance_score": round(
            sum(v["compliance_score"] for v in vendors) / max(len(vendors), 1), 1
        ),
        "high_risk_count": sum(1 for v in vendors if v["risk_score"] >= 60),
    }


@app.get("/api/graph/nodes")
def get_graph_nodes(node_type: str = None, limit: int = 200):
    """Get graph nodes, optionally filtered by type"""
    nodes = [
        {"id": n, **data}
        for n, data in kg.G.nodes(data=True)
        if not node_type or data.get("type") == node_type
    ]
    return {"total": len(nodes), "nodes": nodes[:limit]}


@app.get("/api/graph/edges")
def get_graph_edges(limit: int = 500):
    """Get graph edges/relationships"""
    edges = [
        {"source": u, "target": v, "type": d.get("rel_type", "")}
        for u, v, d in kg.G.edges(data=True)
    ]
    return {"total": len(edges), "edges": edges[:limit]}


@app.get("/api/graph/stats")
def get_graph_stats():
    return kg.get_graph_stats()


@app.get("/api/itc-chain/{invoice_id}")
def get_itc_chain(invoice_id: str):
    """Multi-hop ITC validation chain for a specific invoice"""
    # Try to find by partial match if exact not found
    all_invoice_ids = [
        n for n, d in kg.G.nodes(data=True)
        if d.get("type") == "Invoice"
    ]
    matched = next((n for n in all_invoice_ids if invoice_id in n), None)

    if not matched:
        if all_invoice_ids:
            matched = all_invoice_ids[0]
        else:
            raise HTTPException(status_code=404, detail="Invoice not found")

    chain = kg.get_itc_chain(matched)
    return chain


@app.get("/api/audit/{mismatch_id}")
def get_audit_trail(mismatch_id: str):
    """Detailed audit trail with NL explanation for a specific mismatch"""
    mismatch = next(
        (m for m in report["mismatches"] if m["mismatch_id"] == mismatch_id),
        None
    )
    if not mismatch:
        raise HTTPException(status_code=404, detail="Mismatch not found")

    return {
        **mismatch,
        "nl_explanation": engine.generate_natural_language_explanation(mismatch),
        "graph_path": f"Traversal: Invoice → IRN → EWayBill → GSTR1 → GSTR2B → GSTR3B → Payment",
    }


@app.get("/api/vendor/{gstin}/network")
def get_vendor_network(gstin: str, depth: int = 2):
    """Supply network graph for a vendor GSTIN"""
    return kg.find_vendor_network(gstin, depth)


@app.get("/api/circular-itc")
def detect_circular_itc():
    """Detect potential circular ITC fraud rings"""
    cycles = kg.detect_circular_itc()
    return {
        "cycles_found": len(cycles),
        "cycles": cycles,
        "risk": "HIGH" if cycles else "LOW"
    }


@app.get("/api/reconciliation/report")
def get_full_report():
    """Complete reconciliation report"""
    return report


@app.get("/api/mismatch-types")
def get_mismatch_types():
    return {"types": [e.value for e in MismatchType]}


@app.get("/api/risk-levels")
def get_risk_levels():
    return {"levels": [e.value for e in RiskLevel]}


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
